//
//  NSString+URL.h
//  sdata
//
//  Created by 白静 on 6/2/16.
//  Copyright © 2016 卢坤. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URL)
- (NSString *)URLEncodedString;
@end
