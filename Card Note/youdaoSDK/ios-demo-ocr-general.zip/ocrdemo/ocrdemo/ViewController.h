//
//  ViewController.h
//  ocrdemo
//
//  Created by lilu on 2017/7/6.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

