//
//  YDOCRView.h
//  famyidemo
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YDOCRResult;
@interface YDOCRView : UIView

@property (nonatomic, assign) CGFloat xScale;
@property (nonatomic, assign) CGFloat yScale;

- (void)drawTextInOCRView:(YDOCRResult *)result;
@end
