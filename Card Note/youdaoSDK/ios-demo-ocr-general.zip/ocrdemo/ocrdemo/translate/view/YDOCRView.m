//
//  YDOCRView.m
//  famyidemo
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 网易有道. All rights reserved.
//

#import "YDOCRView.h"
#import "OCRSDK.h"
#import "YDOCRResult.h"
#import "YDOCRRegion.h"
#import "YDOCRLine.h"
#import "YDOCRWord.h"

@implementation YDOCRView
- (void)drawTextInOCRView:(YDOCRResult *)result {
    if (result) {
        for (YDOCRRegion *region in result.regions) {
            for (YDOCRLine *line in region.lines) {
                for (YDOCRWord *word in line.words) {
                    NSString *boundingBox = word.boundingBox;
                    if (!boundingBox.length) {
                        return;
                    }
                    
                    NSArray *subStrs = [boundingBox componentsSeparatedByString:@","];
                    if (!(subStrs.count == 4)) {
                        return;
                    }
                    
                    CGFloat x = [subStrs[0] floatValue] * self.xScale;
                    CGFloat y = [subStrs[1] floatValue] * self.yScale;;
                    CGFloat w = [subStrs[2] floatValue] * self.xScale;;
                    CGFloat h = [subStrs[3] floatValue] * self.yScale;;
                    CGRect rect = CGRectMake(x, y, w, h);
                    UILabel *label = [UILabel new];
                    label.numberOfLines = 0;
                    label.font = [UIFont systemFontOfSize: h * 0.8];
                    label.frame = rect;
                    label.text = word.word;
                    [self addSubview:label];
                }
            }
        }
        CGFloat textAngle = [result.textAngle floatValue];
        self.transform = CGAffineTransformMakeRotation(textAngle * M_PI / 180);
    }
}
@end
