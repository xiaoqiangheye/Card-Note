//
//  OCROnlineController.m
//  famyidemo
//
//  Created by lilu on 2017/7/3.
//  Copyright © 2017年 网易有道. All rights reserved.
//

#import "OCROnlineController.h"
#import "XUtil.h"
#import "UIView_extra.h"
#import "ACMacros.h"
#import "HUDUtil.h"
#import "YDImageView.h"
#import "YDOCRView.h"
#import "YDOCRResult.h"
#import "YDOCRRegion.h"
#import "YDOCRLine.h"
#import "YDOCRWord.h"
#import "DropDown.h"
#import "OCRSDK.h"

@interface OCROnlineController () <UIActionSheetDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,DropDownDelagete>{
    
    DropDown *dd;
    YDOnlineLanguageTool *tool;
    
}
@property (nonatomic, strong) UIScrollView *slView;

@property (nonatomic, strong) YDOCRView *ocrView;

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *textLabel;
@property (nonatomic, strong) YDImageView *imgView;

@end

@implementation OCROnlineController

#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpViews];
}

#pragma mark - functions
- (void)setUpViews {
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    CGSize barSize = CGSizeMake(25, 25);
    UIView *titleView = [UIView new];
    UILabel *selectLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, barSize.width*3, barSize.height)];
    selectLabel.text = @"选取照片 ";
    [selectLabel.layer setCornerRadius:8.0];
    selectLabel.layer.backgroundColor = [[UIColor whiteColor] CGColor];
    
    selectLabel.font = [UIFont systemFontOfSize:16];
    [selectLabel setTextColor:[UIColor blackColor]];
    UITapGestureRecognizer *leftTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectImage)];
    [selectLabel addGestureRecognizer:leftTap];
    selectLabel.userInteractionEnabled = YES;
    [titleView addSubview:selectLabel];
    
    NSString *titleStr = @"开始识别 ";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor blackColor]];
    [titleLabel.layer setCornerRadius:8.0];
    titleLabel.layer.backgroundColor = [[UIColor whiteColor] CGColor];
    titleLabel.frame = CGRectMake(selectLabel.width + 10, 0, titleStrSize.width,barSize.height);
    titleLabel.text = titleStr;
    UITapGestureRecognizer *titleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(startOCR)];
    [titleLabel addGestureRecognizer:titleTap];
    titleLabel.userInteractionEnabled = YES;
    [titleView addSubview:titleLabel];
    
    titleView.frame = CGRectMake(0, 0, CGRectGetMaxX(titleLabel.frame), barSize.height);
    self.navigationItem.titleView = titleView;
    
    UIScrollView *slView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, Main_Screen_Width, Main_Screen_Height - kStatusBarHeight - kTopBarHeight)];
    [self.view addSubview:slView];
    slView.contentSize = slView.size;
    self.slView = slView;
    tool = [[YDOnlineLanguageTool alloc]init];
    CGFloat tableH;
    if (tool.textLanguage.count < 10) {
        tableH = 35 * (tool.textLanguage.count + 1);
    }else{
        tableH = 35 * 10;
    }
    
    dd = [[DropDown alloc] initWithFrame:CGRectMake(Main_Screen_Width/2-(Main_Screen_Width/2 - 35)/2, 10, Main_Screen_Width/2 - 35, tableH)];
    
    dd.tableArray = tool.ocrLanguage;
    dd.textField.text = @"自动";
    dd.delegate = self;
    [self.view addSubview:dd];
    
}

- (void)selectImage {
    //选择头像
    UIActionSheet *sheet;
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        sheet = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"从相册选择", nil];
    }else {
        sheet = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从相册选择", nil];
    }
    [sheet showInView:self.view];
}

- (void)startOCR {
    if (self.imgView.image == nil) {
        [HUDUtil show:self.view text:@"请先选择图片"];
        return;
    }
    
    //将图片转为base64编码字符串，然后调用接口查询
    [HUDUtil show:self.view text:@"正在识别..."];
    NSString *base64Str = [self image2DataURL:self.imgView.image];
    YDOCRRequest *request = [YDOCRRequest request];
    YDOCRParameter *param = [YDOCRParameter param];
    param.langType = tool.ocrLanguageCode[dd.languageNubmer]; //设置识别语言为英文
    param.source = @"youdaoocr"; //设置源
    param.detectType = @"10012"; //设置识别类型，按字识别：10011；按行识别：10012
    request.param = param;
    [request lookup:base64Str WithCompletionHandler:^(YDOCRRequest *request, NSDictionary *result, NSError *error) {
        if (error) {
            //失败
            NSLog(@"error:%@", error);
            [HUDUtil show:self.view text:@"识别失败"];
        }else {
            //成功
            NSLog(@"%@", result);[HUDUtil show:self.view text:@"识别成功"];
            NSDictionary *info = result[@"Result"];
            YDOCRResult *result= [YDOCRResult initWithDict:info];
            [self handleOCRReuslt:result];
        }
    }];
}

- (void)handleOCRReuslt:(YDOCRResult *)result {
    //1.在view中重绘识别出的label
    if (self.imgView.image && self.imgView.image.size.width > 0 && self.imgView.image.size.height > 0) {
        
        self.imgView.xScale = self.imgView.size.width / self.imgView.image.size.width;
        self.imgView.yScale = self.imgView.size.height / self.imgView.image.size.height;
    }else {
        self.imgView.xScale = 1.0;
        self.imgView.yScale = 1.0;
    }
//    [self drawTextInOCRView:result];
    
    //2.在图片中将识别结果用矩形标出
    [self drawRectInImageView:result];
    
    //3.将识别结果打印
    [self showTextInSlView:result];
}

- (void)drawRectInImageView:(YDOCRResult *)result {
    self.imgView.result = result;
    [self.imgView.bgView setNeedsDisplay];
}

- (void)drawTextInOCRView:(YDOCRResult *)result {
    self.ocrView.xScale = self.imgView.xScale;
    self.ocrView.yScale = self.imgView.yScale;
    [self.ocrView removeAllSubviews];
    self.ocrView.frame = CGRectMake(self.imgView.x, CGRectGetMaxY(self.imgView.frame) + 10, self.imgView.width, self.imgView.height);
    [self.ocrView drawTextInOCRView:result];
}

- (void)showTextInSlView:(YDOCRResult *)result {
    self.titleLabel.text = @"识别结果： ";
    CGSize titleSize = [XUtil sizeWithString:self.titleLabel.text font:self.titleLabel.font maxSize:CGSizeZero];
    self.titleLabel.frame = CGRectMake(self.imgView.x, CGRectGetMaxY(self.imgView.frame) + 10, titleSize.width, titleSize.height);
    
    self.textLabel.text = [self textFromOCRResult:result];
    CGSize textSize = [XUtil sizeWithString:self.textLabel.text font:self.textLabel.font maxSize:CGSizeMake(self.imgView.width, 0)];
    self.textLabel.frame = CGRectMake(self.titleLabel.x, CGRectGetMaxY(self.titleLabel.frame) + 10, textSize.width, textSize.height);
    self.slView.contentSize = CGSizeMake(self.view.width, CGRectGetMaxY(self.textLabel.frame) + 10);
}

- (NSString *)textFromOCRResult:(YDOCRResult *)result {
    NSString *resStr = @"";
    if (result) {
        for (YDOCRRegion *region in result.regions) {
            for (YDOCRLine *line in region.lines) {
                for (YDOCRWord *word in line.words) {
                    resStr = [resStr stringByAppendingString:[NSString stringWithFormat:@"%@ ", word.word]];
                }
                resStr = [resStr stringByAppendingString:@"\n\n"];
            }
            resStr = [resStr stringByAppendingString:@"\n\n\n"];
        }
    }
    return resStr;
}

- (BOOL)imageHasAlpha:(UIImage *)image {
    CGImageAlphaInfo alpha = CGImageGetAlphaInfo(image.CGImage);
    return (alpha == kCGImageAlphaFirst ||
            alpha == kCGImageAlphaLast ||
            alpha == kCGImageAlphaPremultipliedFirst ||
            alpha == kCGImageAlphaPremultipliedLast);
}

- (NSString *)image2DataURL:(UIImage *)image {
    NSData *imageData = nil;
    if ([self imageHasAlpha: image]) {
        imageData = UIImagePNGRepresentation(image);
    } else {
        imageData = UIImageJPEGRepresentation(image, 0.01f);
    }
    return [imageData base64EncodedStringWithOptions:0];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSUInteger sourceType = 0;
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        switch (buttonIndex) {
            case 0:{
                //相机
                sourceType = UIImagePickerControllerSourceTypeCamera;
                break;
            }
            case 1:{
                //相册
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                break;
            }
            case 2:{
                //取消
                return;
                break;
            }
                
            default:
                break;
        }
    }else {
        if (buttonIndex == 0) {
            sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        }else {
            //取消
            return;
        }
    }
    
    //跳转到相机或者相册界面
    UIImagePickerController *pickerVc = [[UIImagePickerController alloc] init];
    pickerVc.delegate = self;
    pickerVc.allowsEditing = YES;
    pickerVc.sourceType = sourceType;
    [self presentViewController:pickerVc animated:YES completion:^{
        
    }];
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    
    [self.slView removeAllSubviews];
    CGFloat padding = 30;
    YDImageView *imgView = [[YDImageView alloc] initWithFrame:CGRectMake(padding, padding, self.view.width - padding * 2, self.view.width - padding * 2)];
    [self.slView addSubview:imgView];
    self.imgView = imgView;
    self.imgView.image = image;
    
    YDOCRView *ocrView = [YDOCRView new];
    [self.slView addSubview:ocrView];
    self.ocrView = ocrView;
    
    UILabel *titleLabel = [UILabel new];
    [self.slView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    UILabel *textLabel = [UILabel new];
    textLabel.numberOfLines = 0;
    [self.slView addSubview:textLabel];
    self.textLabel = textLabel;
    self.slView.contentSize = self.slView.size;
}
@end
