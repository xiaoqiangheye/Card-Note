//
//  UIRegisterProtocolViewController.h
//  HiBuy
//
//  Created by TangCui on 15/8/16.
//  Copyright (c) 2015年 xiaoyou. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface IndexViewController : UIViewController

@end
