
//#import "TranslateViewController.h"
#import "IndexViewController.h"
#import "XUtil.h"
#import "OCROnlineController.h"
#import "OCRSDK.h"

@interface IndexViewController () {
    
}
@end

@implementation IndexViewController
- (void)viewDidLoad {
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    //初始化key
    YDTranslateInstance *yd = [YDTranslateInstance sharedInstance];
    yd.appKey = @"your appKey"; //线上

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor whiteColor]];
    NSString *titleStr = @"有道OCR demo";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    titleLabel.frame = CGRectMake(0,50, titleStrSize.width,titleStrSize.height);
    titleLabel.text = titleStr;
    self.navigationItem.titleView = titleLabel;
    self.navigationController.interactivePopGestureRecognizer.delegate=(id)self;
    
    CGFloat padding = 20;
    CGFloat height = 50;
    
    UIButton *ocrOnlineButton = [[UIButton alloc] initWithFrame:CGRectMake(padding,padding, self.view.frame.size.width - padding*2,50)];
    ocrOnlineButton.backgroundColor = [UIColor redColor];
    ocrOnlineButton.tag = 4;
    [self.view addSubview:ocrOnlineButton];
    [ocrOnlineButton setTitle:@"OCR在线识别DEMO" forState:UIControlStateNormal];
    [ocrOnlineButton setTitle:@"OCR在线识别DEMO" forState:UIControlStateSelected];
    [ocrOnlineButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [ocrOnlineButton addTarget:self action:@selector(toDemo:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)toDemo:(UIButton *)sender
{
    NSInteger tag = sender.tag;
    if (tag == 4) {
        OCROnlineController *vc = [[OCROnlineController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}
@end
