//
//  YDOCRWord.m
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import "YDOCRWord.h"

@implementation YDOCRWord
+ (instancetype)initWithDict:(NSDictionary *)info {
    YDOCRWord *word = [[YDOCRWord alloc] init];
    word.boundingBox = info[@"boundingBox"];
    word.word = info[@"word"];
    return word;
}
@end
