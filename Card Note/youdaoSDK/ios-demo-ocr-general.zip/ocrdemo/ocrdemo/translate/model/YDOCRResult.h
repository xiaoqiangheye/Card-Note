//
//  YDOCRResult.h
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOCRResult : NSObject
@property (nonatomic, copy) NSString *orientation;
@property (nonatomic, copy) NSString *textAngle;
@property (nonatomic, copy) NSString *language;
@property (nonatomic, strong) NSArray *regions;
+ (instancetype)initWithDict:(NSDictionary *)info;
@end
/*
 {
 "errorCode": "0",
 "Result": {
 "orientation": "Up",
 "regions": [],
 "textAngle": 0,
 "language": "en"
 }
 }
 */
