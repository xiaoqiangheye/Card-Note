//
//  YDOCRRegion.h
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOCRRegion : NSObject
@property (nonatomic, copy) NSString *boundingBox;
@property (nonatomic, strong) NSArray *lines;

+ (instancetype)initWithDict:(NSDictionary *)info;
@end
/*
 "boundingBox": "27,344,60,21",
 "lines": []
 */
