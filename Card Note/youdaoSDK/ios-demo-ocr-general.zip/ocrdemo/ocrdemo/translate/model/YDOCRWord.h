//
//  YDOCRWord.h
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOCRWord : NSObject
@property (nonatomic, copy) NSString *boundingBox;
@property (nonatomic, copy) NSString *word;

+ (instancetype)initWithDict:(NSDictionary *)info;
@end
/*
 "boundingBox": "27,344,60,21",
 "text": "Class"
 */  
