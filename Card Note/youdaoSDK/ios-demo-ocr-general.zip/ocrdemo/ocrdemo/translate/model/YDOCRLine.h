//
//  YDOCRLine.h
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOCRLine : NSObject
@property (nonatomic, copy) NSString *boundingBox;
@property (nonatomic, copy) NSString *text;
@property (nonatomic, strong) NSArray *words;

+ (instancetype)initWithDict:(NSDictionary *)info;
@end
/*
 "boundingBox": "27,344,60,21",
 "words": [],
 "text":"xxx"
 */
