//
//  YDOCRLine.m
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import "YDOCRLine.h"
#import "YDOCRWord.h"

@implementation YDOCRLine
+ (instancetype)initWithDict:(NSDictionary *)info {
    YDOCRLine *line = [[YDOCRLine alloc] init];
    line.boundingBox = info[@"boundingBox"];
    line.text = info[@"text"];
    NSArray *words = info[@"words"];
    if (words.count) {
        NSMutableArray *arrM = [NSMutableArray array];
        for (NSInteger i = 0; i < words.count; i++) {
            NSDictionary *dict = words[i];
            YDOCRWord *word = [YDOCRWord initWithDict:dict];
            [arrM addObject:word];
        }
        NSArray *array = [NSArray arrayWithArray:arrM];
        line.words = array;
    }
    return line;
}
@end
