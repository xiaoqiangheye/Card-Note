//
//  YDOCRRegion.m
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import "YDOCRRegion.h"
#import "YDOCRLine.h"

@implementation YDOCRRegion
+ (instancetype)initWithDict:(NSDictionary *)info {
    YDOCRRegion *region = [[YDOCRRegion alloc] init];
    region.boundingBox = info[@"boundingBox"];
    NSArray *lines = info[@"lines"];
    if (lines.count) {
        NSMutableArray *arrM = [NSMutableArray array];
        for (NSInteger i = 0; i < lines.count; i++) {
            NSDictionary *dict = lines[i];
            YDOCRLine *line = [YDOCRLine initWithDict:dict];
            [arrM addObject:line];
        }
        NSArray *array = [NSArray arrayWithArray:arrM];
        region.lines = array;
    }
    return  region;
}
@end
