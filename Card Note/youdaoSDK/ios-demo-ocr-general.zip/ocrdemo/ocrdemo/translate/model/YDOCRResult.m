//
//  YDOCRResult.m
//  ocronline
//
//  Created by lilu on 2017/7/4.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import "YDOCRResult.h"
#import "YDOCRRegion.h"

@implementation YDOCRResult
+ (instancetype)initWithDict:(NSDictionary *)info {
    YDOCRResult *result = [[YDOCRResult alloc] init];
    result.orientation = info[@"orientation"];
    result.textAngle = info[@"textAngle"];
    result.language = info[@"language"];
    NSArray *regions = info[@"regions"];
    if (regions.count) {
        NSMutableArray *arrM = [NSMutableArray array];
        for (NSInteger i = 0; i < regions.count; i++) {
            NSDictionary *dict = regions[i];
            YDOCRRegion *region = [YDOCRRegion initWithDict:dict];
            [arrM addObject:region];
        }
        NSArray *array = [NSArray arrayWithArray:arrM];
        result.regions = array;
    }
    return result;
}
@end
