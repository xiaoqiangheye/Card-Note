//
//  AppDelegate.h
//  ocrdemo
//
//  Created by lilu on 2017/7/6.
//  Copyright © 2017年 youdao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *controller;

@end

