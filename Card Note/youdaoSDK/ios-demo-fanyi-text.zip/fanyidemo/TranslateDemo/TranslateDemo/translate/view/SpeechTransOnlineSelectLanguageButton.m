//
//  SpeechTransOnlineSelectLanguageButton.m
//  fanyidemo
//
//  Created by 施润 on 2019/8/9.
//  Copyright © 2019 网易有道. All rights reserved.
//

#import "SpeechTransOnlineSelectLanguageButton.h"


static NSString * Identifie = @"cellIdentifie";

@interface SpeechTransOnlineSelectLanguageButton()<UITableViewDelegate, UITableViewDataSource>{
    
    UITableView *listView;
    
    
}

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSArray *listData;

@end

@implementation SpeechTransOnlineSelectLanguageButton
- (void)didMoveToSuperview{
    [self.superview addSubview:listView];
}
- (void)step{
    
    [self setTitle:self.title forState:UIControlStateNormal];
    [self stepTableView];
    [self setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
    [self addTarget:self action:@selector(listAnimation) forControlEvents:UIControlEventTouchUpInside];
}


- (instancetype)initWithFrame:(CGRect)frame settitle:(NSString *)title setlist:(NSArray *)list{
    
    self = [super initWithFrame:frame];
    
    if(self){
        self.title = title;
        self.listData = list;
        
        [self step];
    }
    
    
    return self;
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return  _listData.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifie];
    
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifie];
    }
    
    cell.textLabel.text =_listData[indexPath.row];
    cell.textLabel.font = self.titleLabel.font;
    cell.textLabel.textColor = [UIColor blackColor];
    
    
    return cell;
}
- (void)listAnimation{
    
    CGRect frame = listView.frame;
    
    if(listView.frame.size.height == 0){
        
        frame.size.height = self.frame.size.height*5;
        
    }else{
        
        frame.size.height = 0;
        
    }
    listView.frame = frame;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self setTitle:_listData[indexPath.row] forState:UIControlStateNormal];
    
    [self.delegate selectLanguage: _listData[indexPath.row] selectBtn:self.tag] ;
    
    
    
    [self listAnimation];
    
}

- (void)stepTableView{
    
    listView = [[UITableView alloc]initWithFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y+self.frame.size.height,self.frame.size.width, 0) style:UITableViewStylePlain];
    
    self.backgroundColor = [UIColor greenColor];

    
    listView.delegate = self;
    listView.dataSource = self;
    
    
}






@end
