//
//  DropDown.h
//  fanyidemo
//
//  Created by 白静 on 12/19/16.
//  Copyright © 2016 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DropDown;
@protocol DropDownDelagete <NSObject>
- (void)dropDownDidSelectLanguage:(DropDown *)dropDown;
@end

@interface DropDown : UIView <UITableViewDelegate,UITableViewDataSource> {
    BOOL showList;//是否弹出下拉列表
    CGFloat tabheight;//table下拉列表的高度
    CGFloat frameHeight;//frame的高度
}

@property (nonatomic,retain) UITableView *tv;
@property (retain,strong) NSArray *tableArray;
@property (nonatomic,retain) UILabel *textField;
@property (nonatomic, assign) NSInteger languageNubmer;
@property (nonatomic,weak) id<DropDownDelagete> delegate;
@end
