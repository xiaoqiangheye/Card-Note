//
//  TranslateView.m
//
//  Created by 白静 on 8/27/16.m
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import "TranslateView.h"
#import "XUtil.h"
#import "ACMacros.h"
@implementation TranslateView

- (instancetype)init {
    if (self = [super init]) {
        self.backgroundColor = [XUtil hexToRGB:@"ecf0f1"];
        self.frame = CGRectMake(0, Main_Screen_Height - 90, Main_Screen_Width, Main_Screen_Height*100/1136);
        CGFloat padding = 22*Main_Screen_Width/640;
        CGFloat size = Main_Screen_Width*60/640;
        CGFloat y = 0;
        UIButton *publishButton = [[UIButton alloc] initWithFrame:CGRectMake(Main_Screen_Width - padding - size*1.8, y, size*1.8, size*1.5)];
        _publishButton = publishButton;
        _publishButton.backgroundColor = [UIColor whiteColor];
        [_publishButton setTitle:@"翻译" forState:UIControlStateNormal];
        [_publishButton setTitle:@"翻译" forState:UIControlStateSelected];
        [_publishButton.layer setCornerRadius:17.0];
        [_publishButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self addSubview:_publishButton];
        _publishButton.titleLabel.font = [UIFont systemFontOfSize: 14.0];

        UITextField *translateContentText = [[UITextField alloc] initWithFrame:CGRectMake(padding, y, Main_Screen_Width - size -padding*4 - Main_Screen_Width*20/640, size*1.5)];
        _translateContentText = translateContentText;
        _translateContentText.font = [UIFont systemFontOfSize:16];
        [_translateContentText setTextColor:[XUtil hexToRGB:@"333333"]];
        _translateContentText.placeholder = @"请输入翻译内容";
        _translateContentText.backgroundColor = [UIColor whiteColor];
        _translateContentText.textAlignment = NSTextAlignmentLeft;
        _translateContentText.layer.borderColor = [UIColor grayColor].CGColor;
        _translateContentText.layer.borderWidth = 1;
        _translateContentText.layer.cornerRadius = 5;
        [self addSubview:_translateContentText];
    }
    return self;
}



//点击屏幕，让键盘弹回
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self endEditing:YES];
}
@end
