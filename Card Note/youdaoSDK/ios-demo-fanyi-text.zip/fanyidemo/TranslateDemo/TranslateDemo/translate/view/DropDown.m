//
//  DropDown.m
//  fanyidemo
//
//  Created by 白静 on 12/19/16.
//  Copyright © 2016 网易有道. All rights reserved.
//

#import "DropDown.h"
#import <Foundation/Foundation.h>

@implementation DropDown

-(id)initWithFrame:(CGRect)frame
{
    if (frame.size.height<200) {
        frameHeight = 200;
    }else{
        frameHeight = frame.size.height;
    }
    tabheight = frameHeight-30;
    
    frame.size.height = 30.0f;
    
    self=[super initWithFrame:frame];
    
    if(self){
        showList = NO; //默认不显示下拉框
        _tv = [[UITableView alloc] initWithFrame:CGRectMake(0, 30, frame.size.width, 0)];
        _tv.delegate = self;
        _tv.dataSource = self;
        _tv.backgroundColor = [UIColor whiteColor];
        _tv.separatorColor = [UIColor lightGrayColor];
        _tv.hidden = YES;
        UIView *view = [UIView new];
        view.backgroundColor = [UIColor clearColor];
        [_tv setTableFooterView:view];
        [self addSubview:_tv];
        
        _textField = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 30)];
        _textField.textAlignment = NSTextAlignmentCenter;
    
        [_textField setUserInteractionEnabled:YES];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dropdown)];
        [_textField addGestureRecognizer:tap];
        [self addSubview:_textField];
        
    }
    return self;
}
-(void)dropdown{
    if (showList) {//如果下拉框已显示，什么都不做
        return;
    }else {//如果下拉框尚未显示，则进行显示
        
        CGRect sf = self.frame;
        sf.size.height = frameHeight;
        
        //把dropdownList放到前面，防止下拉框被别的控件遮住
        [self.superview bringSubviewToFront:self];
        _tv.hidden = NO;
        showList = YES;//显示下拉框
        
        CGRect frame = _tv.frame;
        frame.size.height = 0;
        _tv.frame = frame;
        frame.size.height = tabheight;
        [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        self.frame = sf;
        _tv.frame = frame;
        [UIView commitAnimations];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_tableArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = [_tableArray objectAtIndex:[indexPath row]];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.font = [UIFont systemFontOfSize:16.0f];
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 35;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    _textField.text = [_tableArray objectAtIndex:indexPath.row];
    _languageNubmer = [indexPath row];
    showList = NO;
    _tv.hidden = YES;
    
    CGRect sf = self.frame;
    sf.size.height = 30;
    self.frame = sf;
    CGRect frame = _tv.frame;
    frame.size.height = 0;
    _tv.frame = frame;
    
    if ([self.delegate respondsToSelector:@selector(dropDownDidSelectLanguage:)]) {
        [self.delegate dropDownDidSelectLanguage:self];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
