//
//  SpeechTransOnlineSelectLanguageButton.h
//  fanyidemo
//
//  Created by 施润 on 2019/8/9.
//  Copyright © 2019 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol speechTransDelegate <NSObject>
    
- (void) selectLanguage:(NSString *)language selectBtn:(NSInteger)tag;

@end
@interface SpeechTransOnlineSelectLanguageButton : UIButton
@property (nonatomic, weak)id<speechTransDelegate> delegate;
- (instancetype)initWithFrame:(CGRect)frame settitle:(NSString *)title setlist:(NSArray *)list;
@end

NS_ASSUME_NONNULL_END
