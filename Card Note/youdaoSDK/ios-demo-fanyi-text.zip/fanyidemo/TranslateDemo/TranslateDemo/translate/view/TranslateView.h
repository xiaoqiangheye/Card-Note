//
//  TranslateView.h
//
//  Created by 白静 on 8/27/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TranslateView : UIView
@property (nonatomic, weak) UITextField *translateContentText;
@property (nonatomic, weak) UIButton *publishButton;

@end
