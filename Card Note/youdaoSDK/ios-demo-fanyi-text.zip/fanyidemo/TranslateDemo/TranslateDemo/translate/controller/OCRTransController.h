//
//  OCRTransController.h
//  fanyidemo
//
//  Created by lilu on 2018/4/23.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OCRTransController : UIViewController

@end
