//
//  SpeechOnlineViewController.h
//  fanyidemo
//
//  Created by lilu on 2017/12/14.
//  Copyright © 2017年 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpeechTransOnlineViewController : UIViewController

@end
