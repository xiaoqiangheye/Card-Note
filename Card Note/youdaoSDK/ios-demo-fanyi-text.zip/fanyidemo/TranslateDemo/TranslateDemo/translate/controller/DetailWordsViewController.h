//
//  DetailWordsViewController.h
//  sw-reader
//
//  Created by TangCui on 16/3/9.
//  Copyright © 2016年 Netease Youdao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Translate.h"
#import "TranslateSDK.h"
@interface DetailWordsViewController : UIViewController

@property (nonatomic, strong) Translate *translate;

@end
