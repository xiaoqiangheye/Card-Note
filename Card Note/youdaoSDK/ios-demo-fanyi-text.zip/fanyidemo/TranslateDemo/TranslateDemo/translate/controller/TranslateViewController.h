//
//  UIRegisterProtocolViewController.h
//  HiBuy
//
//  Created by TangCui on 15/8/16.
//  Copyright (c) 2015年 xiaoyou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TranslateView.h"
@interface TranslatesViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,UIPopoverControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate>

//图片相关
@property (retain, nonatomic)UIView *bottomView;

@property (retain,nonatomic)TranslateView *translateView;

@property (retain,nonatomic)NSMutableDictionary *translate;
@end
