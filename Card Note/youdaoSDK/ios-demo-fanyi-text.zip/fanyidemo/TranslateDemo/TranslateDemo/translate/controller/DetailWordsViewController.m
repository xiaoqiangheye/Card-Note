//
//  DetailWordsViewController.m
//  sw-reader
//
//  Created by TangCui on 16/3/9.
//  Copyright © 2016年 Netease Youdao. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "DetailWordsViewController.h"
#import "ACMacros.h"
#import "XUtil.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"

@interface DetailWordsViewController () {
}

@property(nonatomic, retain) MBProgressHUD *HUD;

@property (nonatomic, assign) BOOL collectWord;

@property (nonatomic, strong) UIImageView *collectPicView;

@property (nonatomic, strong) UIButton *pronounce;

@property (nonatomic, strong) UIButton *USSpeak;

@property (nonatomic, strong) UIButton *UKSpeak;

@property (nonatomic, strong) AVAudioPlayer *player; //播放器

@end

@implementation DetailWordsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor whiteColor]];
    NSString *titleStr = @"单词释义";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    titleLabel.frame = CGRectMake(0,50, titleStrSize.width,titleStrSize.height);
    titleLabel.text = titleStr;
    self.navigationItem.titleView = titleLabel;
    
    [self showQueryView];
}


-(void) showQueryView{
    UIView *view = [[UIView alloc] init];
    UILabel *word = [[UILabel alloc] init];
    word.font = [UIFont systemFontOfSize:33];
    [word setTextColor:[XUtil hexToRGB:@"191919"]];
    word.numberOfLines = 0;
    word.lineBreakMode = NSLineBreakByTruncatingTail;
    [view addSubview:word];
    
    UIView *pro = [[UIView alloc] init];
    UIButton *pronounce = [[UIButton alloc] init];
    UIButton *USSpeak = [[UIButton alloc]init];
    UIButton *UKSpeak = [[UIButton alloc]init];
    UIImage *image = [UIImage imageNamed:@"00000"];
    NSString *USBtn = [_translate.ydTranslate.USSpeakurl length] > 0 ? [NSString stringWithFormat:@"美式发音"]: nil;
    [USSpeak setTitle:USBtn forState:UIControlStateNormal];

    [USSpeak setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UKSpeak.tag = 3;
    USSpeak.tag = 2;
    
    USSpeak.titleLabel.font = [UIFont systemFontOfSize:10];
    [USSpeak addTarget:self action:@selector(clickPronouncing:) forControlEvents:UIControlEventTouchUpInside];
    NSString *UKBtn = [_translate.ydTranslate.UKSpeakurl length] > 0 ? [NSString stringWithFormat:@"英式发音"]: nil;
    [UKSpeak setTitle:UKBtn forState:UIControlStateNormal];
    [UKSpeak setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UKSpeak.titleLabel.font = [UIFont systemFontOfSize:10];
    [UKSpeak addTarget:self action:@selector(clickPronouncing:) forControlEvents:UIControlEventTouchUpInside];
    [pronounce.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [pronounce setImage:image forState:UIControlStateNormal];
    [pronounce setImage:image forState:UIControlStateHighlighted];
    pronounce.tag = 1;
    [pronounce addTarget:self action:@selector(clickPronouncing:) forControlEvents:UIControlEventTouchUpInside];
    [pro addSubview:pronounce];
    [pro addSubview:USSpeak];
    [pro addSubview:UKSpeak];
    _pronounce = pronounce;
    _USSpeak = USSpeak;
    _UKSpeak = UKSpeak;
    
    UILabel *pronounceStr = [[UILabel alloc] init];
    pronounceStr.font = [UIFont systemFontOfSize:17];
    [pronounceStr setTextColor:[XUtil hexToRGB:@"808080"]];
    pronounceStr.numberOfLines = 0;
    pronounceStr.lineBreakMode = NSLineBreakByTruncatingTail;
    [pro addSubview:pronounceStr];
    
    UITapGestureRecognizer *proTap = [[UITapGestureRecognizer alloc] init];
    //WithTarget:self action:@selector(clickPronouncing:)];
    [pro addGestureRecognizer:proTap];
    [view addSubview:pro];
    
    UILabel *explain = [[UILabel alloc] init];
    explain.font = [UIFont systemFontOfSize:17];
    [explain setTextColor:[XUtil hexToRGB:@"333333"]];
    explain.numberOfLines = 0;
    explain.lineBreakMode = NSLineBreakByTruncatingTail;
    [view addSubview:explain];
    

    
    UIView *collectView = [[UIView alloc] init];
    UIImageView *collectPicView = [[UIImageView alloc] initWithFrame:CGRectMake(Main_Screen_Width * 20 / 640, Main_Screen_Width * 20 / 640, 40, 40)];
    [collectPicView setImage:[UIImage imageNamed:@"add_word_n"]];
    collectPicView.userInteractionEnabled = YES;
    [collectView addSubview:collectPicView];
    _collectPicView = collectPicView;
    [view addSubview:collectView];
    
    _collectWord = NO;
    
    
    word.text = _translate.content;
    
    NSString *ukphone = [_translate.ydTranslate.ukPhonetic length] > 0 ? [NSString stringWithFormat:@" 英式发音: [%@]", _translate.ydTranslate.ukPhonetic] : nil;
    NSString *usphone = [_translate.ydTranslate.usPhonetic length] > 0 ? [NSString stringWithFormat:@" 美式发音: [%@]", _translate.ydTranslate.usPhonetic] : nil;
    NSString *phone = [_translate.ydTranslate.phonetic length] > 0 ? [NSString stringWithFormat:@" 发音:[%@]", _translate.ydTranslate.phonetic ] : nil;
    if (!ukphone && !usphone && !phone) {
    } else {
        pronounceStr.text = [NSString stringWithFormat:@"%@\n%@\n%@",phone,usphone,ukphone];

    }
    
    NSString *means = @"";
    for (NSString *dict in _translate.ydTranslate.translation) {
        means = [means stringByAppendingString:[NSString stringWithFormat:@"%@\n",dict]];
    }
    
    NSString *webMeans = @"";
    
    for(YDWebExplain *web in _translate.ydTranslate.webExplains){
        webMeans = [webMeans stringByAppendingString:[NSString stringWithFormat:@"%@:",web.key]];
        webMeans = [webMeans stringByAppendingString:@"\n"];

        for(NSString *val in web.value){
            webMeans = [webMeans stringByAppendingString:[NSString stringWithFormat:@"%@",val]];
            webMeans = [webMeans stringByAppendingString:@"\n"];
        }
        webMeans = [webMeans stringByAppendingString:@"\n"];
    }
    
       for(YDWfExplain *wf in _translate.ydTranslate.wfs){
           webMeans = [webMeans stringByAppendingString:[NSString stringWithFormat:@"%@:",wf.name]];
           webMeans = [webMeans stringByAppendingString:@"\n"];
           webMeans = [webMeans stringByAppendingString:[NSString stringWithFormat:@"%@",wf.value]];
               webMeans = [webMeans stringByAppendingString:@"\n"];
           
           webMeans = [webMeans stringByAppendingString:@"\n"];
       }
    
    
    NSString *json = _translate.ydTranslate.json;
    

    
    NSString *explainStr = [NSString stringWithFormat:@"翻译结果：\n%@\n网络释义：\n%@\n原始数据：\n%@",means,webMeans,json]; ;
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:explainStr attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]}];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:10];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [explainStr length])];
    [explain setAttributedText:attributedString];
        
    
    NSString *wordStr = _translate.content;
    CGSize size = CGSizeMake(Main_Screen_Width - Main_Screen_Width * 96 / 640,0);
    CGSize wordSize = [wordStr boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:33]} context:nil].size;
    word.frame = CGRectMake(Main_Screen_Width * 48 / 640, Main_Screen_Width * 48 / 640, wordSize.width, wordSize.height);
    
    CGFloat spacingY = 0;
    
    NSString *pStr = @"";
        if (ukphone) {
            pStr = ukphone;
        } else if (usphone) {
            pStr = usphone;
        } else {
            pStr = phone;
        }
    pronounce.frame = CGRectMake(Main_Screen_Width - 250*Main_Screen_Width/640, Main_Screen_Height * 0 / 1136, Main_Screen_Width * 50 / 640, Main_Screen_Width * 50 / 640);

    USSpeak.frame = CGRectMake(Main_Screen_Width - 300*Main_Screen_Width/640, Main_Screen_Height * 46 / 1136, Main_Screen_Width * 100 / 640, Main_Screen_Width * 50 / 640);
    
    UKSpeak.frame = CGRectMake(Main_Screen_Width - 300*Main_Screen_Width/640, Main_Screen_Height * 100 / 1136, Main_Screen_Width * 100 / 640, Main_Screen_Width * 50 / 640);
    
    
    CGSize psize = CGSizeMake(Main_Screen_Width - Main_Screen_Width * 146 / 640,0);
    CGSize pStrSize = [[NSString stringWithFormat:@"%@\n%@\n%@",phone,usphone,ukphone] boundingRectWithSize:psize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size;
    pronounceStr.frame = CGRectMake( Main_Screen_Width * 12 / 640, CGRectGetMaxY(USSpeak.frame) - USSpeak.frame.size.height / 2 - pStrSize.height/2, pStrSize.width, pStrSize.height);
    pro.frame = CGRectMake(CGRectGetMinX(word.frame) - 3, CGRectGetMaxY(word.frame), Main_Screen_Width - Main_Screen_Width * 150 / 640, MAX(Main_Screen_Width * 50 / 640, pStrSize.height) + Main_Screen_Width * 22 / 640);
    spacingY = CGRectGetMaxY(pro.frame) + Main_Screen_Height * 46 / 1136;

    UILabel *spacingLineLabel = [[UILabel alloc] init];
    [spacingLineLabel setBackgroundColor: [XUtil hexToRGB:@"f3f3f3"]];
    spacingLineLabel.frame = CGRectMake(CGRectGetMinX(word.frame), spacingY, Main_Screen_Width, 1);
    [view addSubview:spacingLineLabel];
    
    CGSize explainSize = [attributedString boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
    explain.frame = CGRectMake(Main_Screen_Width * 48 / 640,CGRectGetMaxY(spacingLineLabel.frame) + Main_Screen_Height * 46 / 1136, explainSize.width,explainSize.height);
    
    collectView.frame = CGRectMake(Main_Screen_Width - Main_Screen_Width * 160 / 640, CGRectGetMaxY(word.frame) - wordSize.height / 2 - Main_Screen_Width * 60 / 640, Main_Screen_Width * 120 / 640,Main_Screen_Width * 120 / 640);
    
    UILabel *spacingLineLabel1 = [[UILabel alloc] init];
    [spacingLineLabel1 setBackgroundColor: [XUtil hexToRGB:@"f3f3f3"]];
    spacingLineLabel1.frame = CGRectMake(CGRectGetMinX(word.frame), CGRectGetMaxY(explain.frame) + Main_Screen_Height * 46 / 1136, Main_Screen_Width, 1);
    [view addSubview:spacingLineLabel1];
    
    
    UILabel *moreLabel = [[UILabel alloc] init];
    moreLabel.font = [UIFont systemFontOfSize:17];
    [moreLabel setTextColor:[UIColor blueColor]];
    moreLabel.numberOfLines = 1;
    moreLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *moreTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toDict)];
    [moreLabel addGestureRecognizer:moreTap];
    
    moreLabel.textAlignment = NSTextAlignmentLeft;
    [view addSubview:moreLabel];
    moreLabel.text = @"查看更多";
    moreLabel.frame = CGRectMake(CGRectGetMinX(word.frame), CGRectGetMaxY(spacingLineLabel1.frame) + Main_Screen_Height * 46 / 1136, Main_Screen_Width, 30);

    
    [view setFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width,CGRectGetMaxY(moreLabel.frame) + Main_Screen_Width * 200 / 640)];
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, Main_Screen_Height)];
    [scrollView setContentSize:view.frame.size];
    [scrollView addSubview:view];
    [scrollView setScrollEnabled:YES];
    [scrollView setBackgroundColor:[UIColor whiteColor]];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrollView];
    
}


-(void)toDict{
    //    //跳转到词典
    [_translate.ydTranslate openMore];
}

- (void)clickPronouncing:(id)sender
{
    UIButton * senderBtn = (UIButton *)sender;
    switch (senderBtn.tag) {
        case 1:
            [self playSound:_translate.ydTranslate.tspeakurl];
            break;
        case 2:
            [self playSound:_translate.ydTranslate.USSpeakurl];
            break;
        case 3:
            [self playSound:_translate.ydTranslate.UKSpeakurl];
            break;
    }
    
}

//发音
- (void)playSound:(NSString *)urlStr {
    if (urlStr == nil || urlStr.length == 0) {
        return;
    }
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        self.player = [[AVAudioPlayer alloc] initWithData:data error:nil];
        [self.player play];
    }];
}

-(void) backIndex{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
