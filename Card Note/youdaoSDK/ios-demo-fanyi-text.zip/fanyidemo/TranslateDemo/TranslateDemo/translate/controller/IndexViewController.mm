
#import "YDConstants.h"
#import "IndexViewController.h"
#import "IndexCell.h"
#import "TranslateSDK.h"
#import "ACMacros.h"

@interface IndexViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSArray *dataSource;
@property (nonatomic, strong) NSArray *vcSource;
@end

@implementation IndexViewController
- (void)viewDidLoad {
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];

    
    self.dataSource = @[@"英汉、小语种在线翻译DEMO", @"在线语音翻译DEMO", @"在线图片翻译DEMO"];
    self.vcSource = @[@"TranslatesViewController",@"SpeechTransOnlineViewController", @"OCRTransController"];
    //初始化key
    YDTranslateInstance *yd = [YDTranslateInstance sharedInstance];
   
    yd.appKey = @"your appkey";
//    yd.isHaiWai = YES;
//    yd.isTestMode = YES;

    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Main_Screen_Width, Main_Screen_Height - kTopBarHeight - kStatusBarHeight)];
    [self.view addSubview:tableView];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.separatorStyle = UITableViewCellEditingStyleNone;
    self.navigationItem.title = @"有道翻译demo";
}


#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IndexCell *cell = [IndexCell cellWithTableView:tableView];
    cell.indexLabel.text = self.dataSource[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Class vcClass = NSClassFromString(self.vcSource[indexPath.row]);
    NSObject *vc = [[vcClass alloc] init];
    if ([vc isKindOfClass:[UIViewController class]]) {
        [self.navigationController pushViewController:(UIViewController *)vc animated:YES];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}
@end
