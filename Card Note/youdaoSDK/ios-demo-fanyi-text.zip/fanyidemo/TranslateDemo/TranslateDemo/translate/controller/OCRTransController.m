//
//  OCRTransController.m
//  fanyidemo
//
//  Created by lilu on 2018/4/23.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "OCRTransController.h"
#import "XUtil.h"
#import "UIView_extra.h"
#import "ACMacros.h"
#import "HUDUtil.h"
#import "YDOCRTransResult.h"
#import "YDOCRTransRegion.h"
#import "MJExtension.h"
#import "YDConstants.h"
#import "TranslateSDK.h"
#import "DropDown.h"

@interface OCRTransController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,DropDownDelagete>{
    
    YDOnlineLanguageTool *tool;
    DropDown *dd1;
    DropDown *dd2;
}
@property (nonatomic, strong) UIScrollView *slView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *textView;
@property (nonatomic, strong) UIImageView *imgView;
@end

@implementation OCRTransController

#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpViews];
    
    [YDTranslateInstance sharedInstance].appKey = yd_kIndexOnlineAppkey;
    [YDTranslateInstance sharedInstance].isTestMode = NO;
}

#pragma mark - functions
- (void)setUpViews {
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    CGSize barSize = CGSizeMake(25, 25);
    UIView *titleView = [UIView new];
    UILabel *selectLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, barSize.width*3, barSize.height)];
    selectLabel.text = @"选取照片 ";
    [selectLabel.layer setCornerRadius:8.0];
    selectLabel.layer.backgroundColor = [[UIColor whiteColor] CGColor];
    
    selectLabel.font = [UIFont systemFontOfSize:16];
    [selectLabel setTextColor:[UIColor blackColor]];
    UITapGestureRecognizer *leftTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectImage)];
    [selectLabel addGestureRecognizer:leftTap];
    selectLabel.userInteractionEnabled = YES;
    [titleView addSubview:selectLabel];
    
    NSString *titleStr = @"开始翻译 ";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor blackColor]];
    [titleLabel.layer setCornerRadius:8.0];
    titleLabel.layer.backgroundColor = [[UIColor whiteColor] CGColor];
    titleLabel.frame = CGRectMake(selectLabel.width + 10, 0, titleStrSize.width,barSize.height);
    titleLabel.text = titleStr;
    UITapGestureRecognizer *titleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(startOCRTrans)];
    [titleLabel addGestureRecognizer:titleTap];
    titleLabel.userInteractionEnabled = YES;
    [titleView addSubview:titleLabel];
    
    titleView.frame = CGRectMake(0, 0, CGRectGetMaxX(titleLabel.frame), barSize.height);
    self.navigationItem.titleView = titleView;
    
    tool = [[YDOnlineLanguageTool alloc]init];
    CGFloat tableH;
    if (tool.textLanguage.count < 10) {
        tableH = 35 * (tool.textLanguage.count + 1);
    }else{
        tableH = 35 * 10;
    }
    

    
    
    UIScrollView *slView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, Main_Screen_Width, Main_Screen_Height - kStatusBarHeight - kTopBarHeight)];
    [self.view addSubview:slView];
    slView.contentSize = slView.size;
    self.slView = slView;
    
    dd1 = [[DropDown alloc] initWithFrame:CGRectMake(10, 10, Main_Screen_Width/2 - 35, tableH)];
    
    dd1.tableArray = tool.ocrLanguage;
    dd1.textField.text = @"自动";
    dd1.delegate = self;
    [self.view addSubview:dd1];
    
    dd2 = [[DropDown alloc] initWithFrame:CGRectMake(Main_Screen_Width-10-(Main_Screen_Width/2 - 35), 10, Main_Screen_Width/2 - 35, tableH)];
    dd2.tableArray = tool.ocrLanguage;
    dd2.textField.text = @"自动";
    dd2.delegate = self;
    [self.view addSubview:dd2];
}

- (void)selectImage {
    //选择头像
    UIActionSheet *sheet;
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        sheet = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"从相册选择", nil];
    }else {
        sheet = [[UIActionSheet alloc] initWithTitle:@"选择" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从相册选择", nil];
    }
    [sheet showInView:self.view];
}

- (void)startOCRTrans {
    if (self.imgView.image == nil) {
        [HUDUtil show:self.view text:@"请先选择图片"];
        return;
    }
    
    //将图片转为base64编码字符串，然后调用接口查询
    [HUDUtil show:self.view text:@"正在识别..."];
    NSString *base64Str = [self image2DataURL:self.imgView.image];
    YDOCRTransRequest *request = [YDOCRTransRequest request];
    YDOCRTransParameter *param = [YDOCRTransParameter param];
    param.from = tool.ocrLanguageCode[dd1.languageNubmer]; //设置源语言
    param.to = tool.ocrLanguageCode[dd2.languageNubmer]; //设置目标语言
    request.param = param;
    [request lookup:base64Str WithCompletionHandler:^(YDOCRTransRequest *request, NSDictionary *info, NSError *error) {
        if (error) {
            //失败
            NSLog(@"error:%@", error);
            [HUDUtil show:self.view text:@"识别失败"];
        }else {
            //成功
            YDOCRTransResult *result = [YDOCRTransResult mj_objectWithKeyValues:info];
            NSLog(@"%@", result);
            [HUDUtil show:self.view text:@"识别成功"];
            [self handleOCRTransReuslt:result];
        }
    }];
}

- (void)handleOCRTransReuslt:(YDOCRTransResult *)result {
    //将识别结果打印
    [self showTextInSlView:result];
}

- (void)showTextInSlView:(YDOCRTransResult *)result {
    self.titleLabel.text = @"识别与翻译结果： ";
    CGSize titleSize = [XUtil sizeWithString:self.titleLabel.text font:self.titleLabel.font maxSize:CGSizeZero];
    self.titleLabel.frame = CGRectMake(self.imgView.x, CGRectGetMaxY(self.imgView.frame) + 10, titleSize.width, titleSize.height);
    
    [self addTextResultToView:result];
    self.slView.contentSize = CGSizeMake(self.view.width, CGRectGetMaxY(self.textView.frame) + 10);
}

- (void)addTextResultToView:(YDOCRTransResult *)result {
    [self.textView removeAllSubviews];
    CGFloat viewWidth = Main_Screen_Width - 2 * self.imgView.x;
    CGFloat viewMaxY = 0;
    if (result) {
        for (NSInteger i = 0; i < result.resRegions.count; i ++) {
            YDOCRTransRegion *region = result.resRegions[i];
            //构建结果view
            UIView *regionView = [[UIView alloc] init];
            regionView.layer.cornerRadius = 4;
            regionView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            regionView.layer.borderWidth = 0.5;
            
            //识别原文
            UILabel *titleContextLabel = [[UILabel alloc] init];
            titleContextLabel.text = [NSString stringWithFormat:@"原文%ld", i + 1];
            titleContextLabel.textColor = [UIColor lightGrayColor];
            titleContextLabel.textAlignment = NSTextAlignmentCenter;
            [regionView addSubview:titleContextLabel];
            
            UILabel *textContextLabel = [[UILabel alloc] init];
            textContextLabel.text = region.context;
            textContextLabel.numberOfLines = 0;
            CGSize contextSize = [XUtil sizeWithString:textContextLabel.text font:textContextLabel.font maxSize:CGSizeMake(viewWidth * 0.8, 0)];
            [regionView addSubview:textContextLabel];
            
            //翻译译文
            UILabel *titleTransLabel = [[UILabel alloc] init];
            titleTransLabel.text = [NSString stringWithFormat:@"译文%ld", i + 1];
            titleTransLabel.textColor = [UIColor lightGrayColor];
            titleTransLabel.textAlignment = NSTextAlignmentCenter;
            [regionView addSubview:titleTransLabel];
            
            UILabel *textTransLabel = [[UILabel alloc] init];
            textTransLabel.text = region.tranContent;
            textTransLabel.numberOfLines = 0;
            CGSize transSize = [XUtil sizeWithString:textTransLabel.text font:textTransLabel.font maxSize:CGSizeMake(viewWidth * 0.8, 0)];
            [regionView addSubview:textTransLabel];
            
            titleContextLabel.frame = CGRectMake(0, 5, viewWidth * 0.2, contextSize.height);
            textContextLabel.frame = CGRectMake(viewWidth * 0.2, 5, viewWidth * 0.8, contextSize.height);
            
            titleTransLabel.frame = CGRectMake(0, contextSize.height + 15, viewWidth * 0.2, transSize.height);
            textTransLabel.frame = CGRectMake(viewWidth * 0.2, contextSize.height + 15, viewWidth * 0.8, transSize.height);
            
            regionView.frame = CGRectMake(self.imgView.x, viewMaxY, viewWidth, contextSize.height + transSize.height + 20);
            [self.textView addSubview:regionView];
            
            viewMaxY = MaxY(regionView) + 10;
        }
    }
    self.textView.frame = CGRectMake(0, MaxY(self.titleLabel) + 10, Main_Screen_Width, viewMaxY);
}

- (NSString *)image2DataURL:(UIImage *)image {
    NSData *imageData = UIImageJPEGRepresentation(image, 1.0);
    return [imageData base64EncodedStringWithOptions:0];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSUInteger sourceType = 0;
    //判断是否支持相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        switch (buttonIndex) {
            case 0:{
                //相机
                sourceType = UIImagePickerControllerSourceTypeCamera;
                break;
            }
            case 1:{
                //相册
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                break;
            }
            case 2:{
                //取消
                return;
                break;
            }
                
            default:
                break;
        }
    }else {
        if (buttonIndex == 0) {
            sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        }else {
            //取消
            return;
        }
    }
    
    //跳转到相机或者相册界面
    UIImagePickerController *pickerVc = [[UIImagePickerController alloc] init];
    pickerVc.delegate = self;
    pickerVc.allowsEditing = YES;
    pickerVc.sourceType = sourceType;
    [self presentViewController:pickerVc animated:YES completion:^{
        
    }];
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    
    [self.slView removeAllSubviews];
    CGFloat padding = 20;
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(padding, padding, self.view.width - padding * 2, self.view.width - padding * 2)];
    [self.slView addSubview:imgView];
    self.imgView = imgView;
    self.imgView.image = image;
    
    UILabel *titleLabel = [UILabel new];
    [self.slView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    UIView *textView = [UIView new];
    [self.slView addSubview:textView];
    self.textView = textView;
    self.slView.contentSize = self.slView.size;
}

@end
