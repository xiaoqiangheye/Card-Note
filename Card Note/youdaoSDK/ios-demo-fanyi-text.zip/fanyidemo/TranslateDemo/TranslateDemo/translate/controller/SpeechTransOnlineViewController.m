//
//  SpeechOnlineViewController.m
//  fanyidemo
//
//  Created by lilu on 2017/12/14.
//  Copyright © 2017年 网易有道. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "SpeechTransOnlineViewController.h"
#import "XUtil.h" 
#import "HUDUtil.h"
#import "TranslateSDK.h"
#import "YDAudioManager.h"
#import "YDSpeechResult.h"
#import "YDConstants.h"
#import "MJExtension.h"
#import "SpeechTransOnlineSelectLanguageButton.h"

static NSString * fromLanguage = @"zh-CHS";
static NSString * toLanguage =  @"en";
@interface SpeechTransOnlineViewController ()<speechTransDelegate>
@property (nonatomic, strong) UIButton *recordBtn;
@property (nonatomic, strong) UIScrollView *resultView;
@property (nonatomic, strong) YDSpeechResult *result; //翻译结果
@property (nonatomic, strong) YDAudioManager *audioManager;
@property (nonatomic, strong) NSDictionary * languageCodeDic;

@end

@implementation SpeechTransOnlineViewController

- (void)selectLanguage:(NSString *)language selectBtn:(NSInteger)tag{
    if(tag){

        toLanguage = [_languageCodeDic valueForKey:language];
    }else{
        fromLanguage = [_languageCodeDic valueForKey:language];
    }

    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpAudioManager];

    [self setUpViews];
    
    [YDTranslateInstance sharedInstance].appKey = yd_kIndexTestAppkey;
    
    [YDTranslateInstance sharedInstance].isTestMode = NO;
}

- (void)setUpAudioManager {
    self.audioManager = [YDAudioManager manager];
    self.audioManager.fileName = @"speechOnline.wav";
}

- (void)setUpViews {
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor whiteColor]];
    NSString *titleStr = @"在线语音翻译";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    titleLabel.frame = CGRectMake(0,50, titleStrSize.width,titleStrSize.height);
    titleLabel.text = titleStr;
    self.navigationItem.titleView = titleLabel;
    
    CGFloat padding = 20;
    CGFloat height = 50;
    UIButton *recordBtn = [[UIButton alloc] initWithFrame:CGRectMake(padding,padding, self.view.frame.size.width - padding*2,50)];
    recordBtn.backgroundColor = [UIColor redColor];
    [self.view addSubview:recordBtn];
    [recordBtn setTitle:@"开始录音" forState:UIControlStateNormal];
    [recordBtn setTitle:@"停止录音" forState:UIControlStateSelected];
    [recordBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [recordBtn addTarget:self action:@selector(recordBtn:) forControlEvents:UIControlEventTouchUpInside];
    self.recordBtn = recordBtn;
    
    UIButton *startTansBtn = [[UIButton alloc] initWithFrame:CGRectMake(padding,padding*2 + height, self.view.frame.size.width - padding*2,50)];
    startTansBtn.backgroundColor = [UIColor redColor];
    [self.view addSubview:startTansBtn];
    [startTansBtn setTitle:@"开始在线语音翻译" forState:UIControlStateNormal];
    [startTansBtn setTitle:@"开始在线语音翻译" forState:UIControlStateSelected];
    [startTansBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [startTansBtn addTarget:self action:@selector(startTansBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    
 //   YDSpeechOnlineRequest * quest = [[YDSpeechOnlineRequest alloc]init];
    
    YDOnlineLanguageTool * tool = [[YDOnlineLanguageTool alloc]init];
    
    _languageCodeDic = tool.languageFanYiCode;
    
    SpeechTransOnlineSelectLanguageButton * fromButton = [[SpeechTransOnlineSelectLanguageButton alloc]initWithFrame:CGRectMake(padding, padding*3 + height*2, self.view.frame.size.width/2 - 2 * padding, 50) settitle:@"中文" setlist:tool.fromLanguage];
    
    SpeechTransOnlineSelectLanguageButton * toButton = [[SpeechTransOnlineSelectLanguageButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2 + padding, padding*3 + height*2, self.view.frame.size.width/2 - 2*padding, 50) settitle:@"英文" setlist:tool.toLanguage];
    fromButton.tag = 0;
    toButton.tag = 1;
    
    fromButton.delegate = self;
    toButton.delegate = self;
    
    
    UIScrollView *resultView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(fromButton.frame) + padding, self.view.frame.size.width, self.view.frame.size.height - (CGRectGetMaxY(toButton.frame) +CGRectGetHeight(toButton.frame)+height+padding))];
    
    [self.view addSubview:resultView];
    
    [self.view addSubview:fromButton];
    [self.view addSubview:toButton];
    self.resultView = resultView;
}

- (void)recordBtn:(UIButton *)btn {
    if (btn.selected) {
        [self stopRecord];
    }else {
        [self startRecord];
    }
    btn.selected = !btn.selected;
}

- (void)startTansBtn:(UIButton *)btn {
    if (self.recordBtn.selected) {
        [self recordBtn:self.recordBtn];
    }
    NSData *speechData = [self.audioManager audioData];
    if (speechData.length) {
        [HUDUtil show:self.view text:@"开始翻译"];
        NSString *base64Str = [speechData base64EncodedStringWithOptions:0];
        YDSpeechOnlineRequest *request = [YDSpeechOnlineRequest request];
        YDSpeechOnlineParam *param = [YDSpeechOnlineParam param];
        param.from = fromLanguage;//源语言
        param.to = toLanguage;//翻译目标语言
        param.rate = @"16000";//采样率
        param.channel = @"1";//声道数，目前只支持单声道，请写固定值1
        param.voice = @"1";  //女声代码为0，男声代码为1，英语有四种：0 美式女声  1 美式男声   2 英式女声  3 英式男声
        request.param = param;
        [request lookup:base64Str WithCompletionHandler:^(YDSpeechOnlineRequest *request, NSDictionary *info, NSError *error) {
            if (!error) {
                YDSpeechResult *result = [YDSpeechResult mj_objectWithKeyValues:info];
                if ([result.errorCode isEqualToString:@"0"]) {
                    [self showResult:result];
                }
            }else {
                [HUDUtil show:self.view text:[NSString stringWithFormat:@"翻译结果错误码:%@", error]];
            }
        }];
    }else {
        [HUDUtil show:self.view text:@"请先录音"];
    }
}

- (void)showResult:(YDSpeechResult *)result {
    [[self.resultView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.result = result;
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, self.resultView.frame.size.width - 40, 20)];
    titleLabel.text = @"翻译结果:";
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.font = [UIFont systemFontOfSize:16];
    [self.resultView addSubview:titleLabel];
    
    //源语言文本
    UILabel *fromLabel = [[UILabel alloc] init];
    fromLabel.numberOfLines = 0;
    fromLabel.text = [NSString stringWithFormat:@"源语言：%@", result.query];;
    fromLabel.textAlignment = NSTextAlignmentLeft;
    fromLabel.font = [UIFont systemFontOfSize:16];
    CGSize fromSize = [XUtil sizeWithString:fromLabel.text font:fromLabel.font maxSize:CGSizeMake(self.resultView.frame.size.width - 40, 0)];
    fromLabel.frame = CGRectMake(20, CGRectGetMaxY(titleLabel.frame) + 20, self.resultView.frame.size.width - 40, fromSize.height);
    [self.resultView addSubview:fromLabel];
    
    //翻译结果
    UILabel *toLabel = [[UILabel alloc] init];
    toLabel.numberOfLines = 0;
    NSString *toStr;
    for (NSString *str in result.translation) {
        toStr = [NSString stringWithFormat:@"%@\n", str];
    }
    toLabel.text = [NSString stringWithFormat:@"目标语言：%@", toStr];
    toLabel.textAlignment = NSTextAlignmentLeft;
    toLabel.font = [UIFont systemFontOfSize:16];
    CGSize toSize = [XUtil sizeWithString:toLabel.text font:toLabel.font maxSize:CGSizeMake(self.resultView.frame.size.width - 40, 0)];
    toLabel.frame = CGRectMake(20, CGRectGetMaxY(fromLabel.frame) + 20, self.resultView.frame.size.width - 40, toSize.height);
    [self.resultView addSubview:toLabel];
    
    //源语言发音
    UIButton *fromSpeakBtn = [[UIButton alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(toLabel.frame) + 20, (self.view.frame.size.width - 20 * 3) * 0.5, 50)];
    fromSpeakBtn.backgroundColor = [UIColor redColor];
    [self.resultView addSubview:fromSpeakBtn];
    [fromSpeakBtn setTitle:@"源语言发音" forState:UIControlStateNormal];
    [fromSpeakBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [fromSpeakBtn addTarget:self action:@selector(fromSpeakBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    //翻译结果发音
    UIButton *toSpeakBtn = [[UIButton alloc] initWithFrame:CGRectMake(20 * 2 + (self.view.frame.size.width - 20 * 3) * 0.5 , CGRectGetMaxY(toLabel.frame) + 20, (self.view.frame.size.width - 20 * 3) * 0.5, 50)];
    toSpeakBtn.backgroundColor = [UIColor redColor];
    [self.resultView addSubview:toSpeakBtn];
    [toSpeakBtn setTitle:@"翻译结果发音" forState:UIControlStateNormal];
    [toSpeakBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [toSpeakBtn addTarget:self action:@selector(toSpeakBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    //词典deeplink
    UIButton *dictDeeplinkBtn = [[UIButton alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(fromSpeakBtn.frame) + 20, (self.view.frame.size.width - 20 * 3) * 0.5, 50)];
    dictDeeplinkBtn.backgroundColor = [UIColor redColor];
    [self.resultView addSubview:dictDeeplinkBtn];
    [dictDeeplinkBtn setTitle:@"词典deeplink" forState:UIControlStateNormal];
    [dictDeeplinkBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [dictDeeplinkBtn addTarget:self action:@selector(dictDeeplinkBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    //web deeplink
    UIButton *webDeeplinkBtn = [[UIButton alloc] initWithFrame:CGRectMake(20 * 2 + (self.view.frame.size.width - 20 * 3) * 0.5 , CGRectGetMaxY(toSpeakBtn.frame) + 20, (self.view.frame.size.width - 20 * 3) * 0.5, 50)];
    webDeeplinkBtn.backgroundColor = [UIColor redColor];
    [self.resultView addSubview:webDeeplinkBtn];
    [webDeeplinkBtn setTitle:@"web deeplink" forState:UIControlStateNormal];
    [webDeeplinkBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [webDeeplinkBtn addTarget:self action:@selector(webDeeplinkBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    self.resultView.contentSize = CGSizeMake(self.view.frame.size.width, MAX(CGRectGetMaxY(webDeeplinkBtn.frame), self.resultView.frame.size.height));
}

- (void)fromSpeakBtnClick:(UIButton *)btn {
    [self playSound:self.result.speakUrl];
}

- (void)toSpeakBtnClick:(UIButton *)btn {
    [self playSound:self.result.tSpeakUrl];
}

//发音
- (void)playSound:(NSString *)urlStr {
    if (urlStr == nil || urlStr.length == 0) {
        return;
    }
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        [self.audioManager playAudio:data];
    }];
}

- (void)dictDeeplinkBtnClick:(UIButton *)btn {
    NSString *dictDeeplinkUrl = self.result.dict[@"url"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:dictDeeplinkUrl]];
}

- (void)webDeeplinkBtnClick:(UIButton *)btn {
    NSString *webDeeplinkUrl = self.result.webdict[@"url"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:webDeeplinkUrl]];
}

#pragma mark - 录音函数
- (void)startRecord {
    [self.audioManager startRecord];
}

- (void)stopRecord {
    [self.audioManager stopRecord];
}
@end
