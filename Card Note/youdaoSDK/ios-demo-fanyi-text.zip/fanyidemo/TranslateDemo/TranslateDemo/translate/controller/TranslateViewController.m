
#import "TranslateViewController.h"
#import "XUtil.h"
#import "AppDelegate.h"
#import "UIView_extra.h"
#import "NSUserDefaultsUtil.h"
#import "HUDUtil.h"
#import "ACMacros.h"
#import "TranslateFrame.h"
#import "TranslateListCell.h"
#import "TranslateSDK.h"
#import "DropDown.h"
#import "FileDownloadUtil.h"
#import "base.h"

@interface TranslatesViewController ()<UIWebViewDelegate,UIGestureRecognizerDelegate,UIAlertViewDelegate, DropDownDelagete> {
    AppDelegate *appDelegate;
    UITableView *roomListTable;
    NSArray *translateFrames;
    NSMutableArray *dataArray;
    long artical;
    NSString *translates;
    NSInteger tag;
    NSString *image;
    NSString *audio;
    CGFloat keyboardSize;
    bool isfirst;
    NSInteger longClickIndex;
    DropDown *dd1;
    DropDown *dd2;
    YDTranslateRequest *translateRequest;
    YDOnlineLanguageTool *tool;
}
@end

@implementation TranslatesViewController
- (void)viewDidLoad {
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide:)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
//    bool b = [[NSURL URLWithString:@"sss"] yd_hasTelephonePromptScheme];

    translateRequest  = [YDTranslateRequest request];
    tool = [[YDOnlineLanguageTool alloc]init];
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [XUtil hexToRGB:@"ecf0f1"];
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self inithead];
    
    CGFloat tableX = 0;
    CGFloat tableY = Main_Screen_Width * 60 / 640;
    CGFloat tableH;
    if (tool.textLanguage.count < 10) {
        tableH = 35 * (tool.textLanguage.count + 1);
    }else{
        tableH = 35 * 10;
    }
    dd1 = [[DropDown alloc] initWithFrame:CGRectMake(10, 10, Main_Screen_Width/2 - 35, tableH)];
    
    dd1.tableArray = tool.textLanguage;
    dd1.textField.text = @"自动";
    dd1.delegate = self;
    [self.view addSubview:dd1];
    
    
    UIImageView *picView = [[UIImageView alloc] initWithFrame:CGRectMake(Main_Screen_Width * 40 / 640, 10, Main_Screen_Width * 50 / 640, Main_Screen_Width * 50 / 640)];
    [picView setImage:[UIImage imageNamed:@"moreicon"]];
    picView.centerX = self.view.centerX;
    [self.view addSubview:picView];
    
    dd2 = [[DropDown alloc] initWithFrame:CGRectMake(MaxX(picView) + 15, 10, Main_Screen_Width/2 - 35, tableH)];
    dd2.tableArray = tool.textLanguage;
    dd2.textField.text = @"自动";
    dd2.delegate = self;
    [self.view addSubview:dd2];
    

    CGFloat tableW = Main_Screen_Width;
    roomListTable = [[UITableView alloc] init];
    roomListTable.frame=CGRectMake(tableX, tableY, tableW, tableH);
    roomListTable.delegate = self;
    roomListTable.dataSource = self;
    roomListTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:roomListTable];
    roomListTable.backgroundColor = [XUtil hexToRGB:@"ecf0f1"];
    [self initbottom];
    
    [self.view sendSubviewToBack:roomListTable];
    [_translateView.translateContentText becomeFirstResponder];
}


- (void) registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardDidHideNotification object:nil];
    //输入法切换
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UITextInputCurrentInputModeDidChangeNotification object:nil];
    
}

- (void) keyboardWasShown:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    keyboardSize = [value CGRectValue].size.height;
    
    [self hideRecordFrame];
    CGFloat translatey = _translateView.centerY;
    _translateView.centerY = translatey - keyboardSize;
    
    CGFloat bottomy = _bottomView.centerY;
    _bottomView.centerY = bottomy - keyboardSize;
    
}
- (void) keyboardWasHidden:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    
    NSValue *value = [info objectForKey:UIKeyboardFrameBeginUserInfoKey];
    keyboardSize = [value CGRectValue].size.height;
    NSLog(@"keyBoard:%f", keyboardSize);  //
    // keyboardWasShown = NO;
    
}

-(void) initbottom
{
    UIView *bottomView = [[UIView alloc] init];
    _bottomView = bottomView;
    _bottomView.frame = CGRectMake(0, Main_Screen_Height- kStatusBarHeight - kTopBarHeight - Main_Screen_Height*100/1136, Main_Screen_Width, 0);
    _bottomView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_bottomView];
    
    TranslateView *translateView = [[TranslateView alloc] init];
    
    translateView.frame = CGRectMake(0,MinY(_bottomView), Main_Screen_Width, Main_Screen_Height*100/1136);
    [self.view addSubview:translateView];
    translateView.translateContentText.delegate = self;
    
    _translateView = translateView;
    
    [_translateView.publishButton addTarget:self action:@selector(publishAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:translateView];
}

- (void)publishAction:(UIButton *)sender
{
    NSString *text = _translateView.translateContentText.text;
    
    translates = text;
    [self minimize];
    
    [self publishtranslate];
}

- (void)publishtranslate{
    _translate = [[NSMutableDictionary alloc] init];
    if(translates != nil){
        [_translate setObject:translates forKey:@"content"];
    }
    NSString *text = [_translate objectForKey:@"content"];
    [self posttranslates];
}

-(void)posttranslates{
    YDTranslateParameters *parameters =
    [YDTranslateParameters targeting];
    parameters.source = @"demo";
    parameters.textFrom = tool.textLanguageCode[dd1.languageNubmer];
    parameters.textTo = tool.textLanguageCode[dd2.languageNubmer];
    parameters.voice = @"1";
    translateRequest.translateParameters = parameters;
    
    [translateRequest lookup:[_translate objectForKey:@"content"] WithCompletionHandler:^(YDTranslateRequest *request, YDTranslate *translte, NSError *error) {
        if (error) {
            NSString *des = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
            NSLog(@"================> %ld%@", (long)error.code,des);
            [HUDUtil show:self.view text:[NSString stringWithFormat:@"查询失败:%@", des]];
        } else {
            if (!translte.translation.count) {
                [HUDUtil show:self.view text:@"抱歉，遇到错误，请重新输入"];
                return;
            }
            NSString *fanyi = translte.translation[0];
            if(fanyi == nil){
                [HUDUtil show:self.view text:@"抱歉，遇到错误，请重新输入"];
                return;
            }
            [_translate setObject:fanyi forKey:@"translate"];
            [_translate setObject:[NSString stringWithFormat:@"%f", [[NSDate date] timeIntervalSince1970]] forKey:@"createstime"];
            Translate *model = [[Translate alloc] init];
            [XUtil dictionaryToEntity:_translate entity:model];
            [model formData];
            model.ydTranslate = translte;
            [self addTrans:model];
            _translateView.translateContentText.text = nil;
        }
    }];
}

- (YDLanguageType)typeFrom:(NSString *)str {
    YDLanguageType type = YDLanguageTypeAuto;
    if ([str isEqualToString:@"自动"]) {
        type = YDLanguageTypeAuto;
    }else if ([str isEqualToString:@"中文"]) {
        type = YDLanguageTypeChinese;
    }else if ([str isEqualToString:@"英文"]) {
        type = YDLanguageTypeEnglish;
    }else if ([str isEqualToString:@"日文"]) {
        type = YDLanguageTypeJapanese;
    }else if ([str isEqualToString:@"韩文"]) {
        type = YDLanguageTypeKorean;
    }else if ([str isEqualToString:@"法文"]) {
        type = YDLanguageTypeFrench;
    }else if ([str isEqualToString:@"俄文"]) {
        type = YDLanguageTypeRussian;
    }else if ([str isEqualToString:@"葡萄牙文"]) {
        type = YDLanguageTypePortuguese;
    }else if ([str isEqualToString:@"西班牙文"]) {
        type = YDLanguageTypeSpanish;
    }else if ([str isEqualToString:@"越南文"]) {
        type = YDLanguageTypeVietnamese;
    }else if ([str isEqualToString:@"中文繁体"]) {
        type = YDLanguageTypeChineseT;
    }else if ([str isEqualToString:@"德文"]) {
        type = YDLanguageTypeGerman;
    }else if ([str isEqualToString:@"阿拉伯文"]) {
        type = YDLanguageTypeArabic;
    }else if ([str isEqualToString:@"印尼文"]) {
        type = YDLanguageTypeIndonesian;
    }
    return type;
}

-(void)minimize{
    _bottomView.frame = CGRectMake(0, Main_Screen_Height- kStatusBarHeight - kTopBarHeight - Main_Screen_Height*100/1136, Main_Screen_Width, 0);
    _translateView.frame = CGRectMake(0,MinY(_bottomView), Main_Screen_Width, Main_Screen_Height*100/1136);
}

-(void)keyboardHide:(UITapGestureRecognizer*)tap{
    [_translateView.translateContentText resignFirstResponder];
}

-(void)showRecordFrame{
    _bottomView.frame = CGRectMake(0,Main_Screen_Height - kStatusBarHeight - kTopBarHeight - Main_Screen_Width*450/640, Main_Screen_Width, Main_Screen_Width*450/640);
    _bottomView.hidden = NO;
    _translateView.frame = CGRectMake(0,MinY(_bottomView), Main_Screen_Width, Main_Screen_Height*100/1136);
    
}

-(void)hideRecordFrame{
    _bottomView.frame = CGRectMake(0,Main_Screen_Height- kStatusBarHeight - kTopBarHeight - Main_Screen_Height*100/1136, Main_Screen_Width,0);
    _bottomView.hidden = YES;
    _translateView.frame = CGRectMake(0,MinY(_bottomView), Main_Screen_Width, Main_Screen_Height*100/1136);
    
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{

}

#pragma mark -DropDownDelagete 
- (void)dropDownDidSelectLanguage:(DropDown *)dropDown {
    NSString *langStr = @"中文";
    if ([YDTranslateInstance sharedInstance].isHaiWai) {
        langStr = @"英文";
    }
//    if (![dd1.textField.text isEqualToString:langStr] && ![dd2.textField.text isEqual:langStr] && ![dd1.textField.text isEqualToString:@"自动"] && ![dd2.textField.text isEqual: @"自动"] && ![dd1.textField.text isEqualToString:@"中文繁体"] && ![dd2.textField.text isEqual: @"中文繁体"]) {
//        [HUDUtil show:self.view text:[NSString stringWithFormat:@"必须有一种语言为%@或自动", langStr]];
//        dropDown.textField.text = langStr;
//    }
}

#pragma mark -屏幕恢复
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    //滑动效果
    CGFloat translatey = _translateView.centerY;
    _translateView.centerY = translatey + keyboardSize;
    
    CGFloat bottomy = _bottomView.centerY;
    _bottomView.centerY = bottomy + keyboardSize;
    
    [self minimize];
    
}


#pragma mark 开始进入刷新状态
- (void)headerRereshing
{
}


-(void) addTrans:(Translate *) trans{
    if(_translate == nil){
        return;
    }
    NSMutableArray *arrM = [[NSMutableArray alloc] init];
    [arrM addObjectsFromArray:dataArray];
    [arrM addObject:trans];
    dataArray = arrM;
    _translate = nil;
    [self refreshTrans];  
}

-(void) delTrans{
    NSMutableArray *arrM = [[NSMutableArray alloc] init];
    [arrM addObjectsFromArray:dataArray];
    [arrM removeObjectAtIndex:longClickIndex];
    dataArray = arrM;
    [NSUserDefaultsUtil putObject:dataArray key:@"translates"];
    _translate = nil;
    [self refreshTrans];
}

- (void)scrollViewToBottom:(BOOL)animated
{
    if (roomListTable.contentSize.height > roomListTable.frame.size.height)
    {
        CGPoint offset = CGPointMake(0, roomListTable.contentSize.height - roomListTable.frame.size.height);
        [roomListTable setContentOffset:offset animated:animated];
    }
}

-(void) refreshTrans{
    NSMutableArray*  tempModels = [NSMutableArray arrayWithCapacity:10];
    
    
    for (Translate *target in dataArray) {
        // 创建模型
        if((NSNull *)target == [NSNull null] || target == nil){
            continue;
        }
//        Translate *model = [[Translate alloc] init];
//        [XUtil dictionaryToEntity:target entity:model];
//        [model formData];
        // 根据模型数据创建frame模型
        TranslateFrame *frame = [[TranslateFrame alloc] init];
        [frame initWithModel:target];
        [tempModels addObject:frame];
    }
    
    translateFrames = [NSArray arrayWithArray:tempModels];
    
    [roomListTable reloadData];
    [self scrollViewToBottom:NO];
}

-(void) inithead{
    CGSize barSize = CGSizeMake(25,25);
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    [titleLabel setTextColor:[UIColor whiteColor]];
    NSString *titleStr = @"在线翻译";
    CGSize titleStrSize = [XUtil sizeWithString:titleStr font:[UIFont systemFontOfSize:16] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    titleLabel.frame = CGRectMake(0,50, titleStrSize.width,titleStrSize.height);
    titleLabel.text = titleStr;
    self.navigationItem.titleView = titleLabel;
    self.navigationController.interactivePopGestureRecognizer.delegate=(id)self;

    
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0,0, Main_Screen_Width * 200 / 640, kTopBarHeight)];
    UIView *deleteView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(rightView.frame)  - Main_Screen_Width * (24 + 82)/640 , 0, Main_Screen_Width * (24+82)/640, kTopBarHeight)];
    UILabel *deleteLabel = [[UILabel alloc]initWithFrame:CGRectMake(Main_Screen_Width * 24/640, kTopBarHeight - barSize.height - 9, barSize.height*2, barSize.height)];
    [deleteView addSubview:deleteLabel];
    deleteLabel.text = @"删除";
    deleteLabel.font = [UIFont systemFontOfSize:16 ];
    [deleteLabel setTextColor:[UIColor redColor]];
    
    UITapGestureRecognizer *deleteTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(deleteTap)];
    [deleteView addGestureRecognizer:deleteTap];
    [rightView addSubview:deleteView];
    
    UIBarButtonItem *btn_right = [[UIBarButtonItem alloc] initWithCustomView:rightView];
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    /**
     *  width为负数时，相当于btn向右移动width数值个像素
     *  width为正数时，正好相反，相当于往左移动width数值个像素
     */
    negativeSpacer.width = -15;
    self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects:negativeSpacer, btn_right, nil];
    
}

-(void) download{
//    NSString *baPath = @"http://nb269x.corp.youdao.com:18080/sdkdev/ba160111.ydd";
//    NSString *bbPath = @"http://nb269x.corp.youdao.com:18080/sdkdev/bb160111.ydd";
    //    NSURLRequest *request1 = [NSURLRequest requestWithURL:[NSURL URLWithString:baPath]];
    //    [NSURLConnection sendAsynchronousRequest:request1 queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
    //        if (error) {
    //            NSLog(@"Download Error:%@",error.description);
    //        }
    //        if (data) {
    //            NSString *filePath = [[XUtil getDownloadPath] stringByAppendingPathComponent:@"ba160111.ydd"];
    //            [data writeToFile:filePath atomically:YES];
    //            NSLog(@"File is saved to %@",filePath);
    //            [HUDUtil show:self.view text:@"下载成功"];
    //        }
    //    }];
    //
    //    NSURLRequest *request2 = [NSURLRequest requestWithURL:[NSURL URLWithString:bbPath]];
    //    [NSURLConnection sendAsynchronousRequest:request2 queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
    //        if (error) {
    //            NSLog(@"Download Error:%@",error.description);
    //        }
    //        if (data) {
    //            NSString *filePath = [[XUtil getDownloadPath] stringByAppendingPathComponent:@"bb160111.ydd"];
    //            [data writeToFile:filePath atomically:YES];
    //            NSLog(@"File is saved to %@",filePath);
    //            [HUDUtil show:self.view text:@"下载成功"];
    //        }
    //    }];

    NSString *juzi = @"https://download.ydstatic.com/dictmobile/dictlib/4.0/iphone/ce.zip";
    [HUDUtil show:self.view text:@"开始下载"];
    
    
    
    NSURLRequest *request3 = [NSURLRequest requestWithURL:[NSURL URLWithString:juzi]];
    [NSURLConnection sendAsynchronousRequest:request3 queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        if (error) {
            NSLog(@"Download Error:%@",error.description);
        }
        if (data) {
            NSString *filePath = [[XUtil getDownloadPath] stringByAppendingPathComponent:@"ce.zip"];
            [data writeToFile:filePath atomically:YES];
            NSLog(@"File is saved to %@",filePath);
            [HUDUtil show:self.view text:@"下载成功"];
        }
    }];
    
}



-(void) deleteTap{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"确定删除全部翻译内容" message:nil delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"删除", nil];
    alert.delegate = self;
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //取消
            break;
        }
        case 1:{
            //确认
            [NSUserDefaultsUtil putObject:nil key:@"translates"];
            dataArray = nil;
            [self refreshTrans];
            break;
        }
        default:
            break;
    }
}

#pragma mark - UITableView DataSoruce And Delegate Methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return translateFrames.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row];
    TranslateFrame *cellFrame = translateFrames[row];
    return cellFrame.cellHeight;
    //        return  100;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return NO;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row];
    TranslateListCell *cell = [TranslateListCell cellWithTableView:tableView];
    
    TranslateFrame *TranslateFrame = translateFrames[row];
    [cell loadWithFrame:TranslateFrame];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //点击cell行时，背景颜色一闪而过
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

-(void) backIndex{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) viewWillAppear:(BOOL)paramAnimated
{
    [super viewWillAppear:paramAnimated];
    self.navigationController.navigationBar.hidden = NO;
    [self registerForKeyboardNotifications];
}

@end
