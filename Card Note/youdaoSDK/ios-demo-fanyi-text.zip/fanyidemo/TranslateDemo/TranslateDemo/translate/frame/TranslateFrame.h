//
//  TranslateFrame.h
//
//  Created by 白静 on 8/17/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Translate.h"
@interface TranslateFrame : NSObject
@property (nonatomic, assign) CGRect rightViewFrame;
@property (nonatomic, assign) CGRect contentFrame;
@property (nonatomic, assign) CGRect translateFrame;
@property (nonatomic, assign) CGRect spacelineFrame;
@property (nonatomic, assign) CGRect timeFrame;

/**
 *  行高
 */
@property (nonatomic, assign) CGFloat cellHeight;
/**
 *  模型数据
 */
@property (nonatomic, strong) Translate *translate;

- (void)initWithModel:(Translate *)translate;
@end
