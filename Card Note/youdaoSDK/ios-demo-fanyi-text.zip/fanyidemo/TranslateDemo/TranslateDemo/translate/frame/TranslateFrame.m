//
//  translateFrame.m
//
//  Created by 白静 on 8/17/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//h

#import "translateFrame.h"
#import "ACMacros.h"
#import "XUtil.h"

@implementation TranslateFrame
- (void)initWithModel:(Translate *)translate{
    _translate = translate;
    
    CGFloat padding = Main_Screen_Width * 20/640;
    CGFloat titleY = padding*2;    
    
    CGFloat titleX = padding*3/2;
    
    CGSize size = CGSizeMake([[UIScreen mainScreen] bounds].size.width - titleX - padding,0);
    NSString *content = translate.content;
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:content attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:8];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [attributedString length])];
    CGSize contentSize = [attributedString boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
    _contentFrame = CGRectMake(titleX + padding /2,titleY , size.width, contentSize.height + padding*2);
    
    
    _spacelineFrame = CGRectMake(titleX, CGRectGetMaxY(_contentFrame) + padding/2, Main_Screen_Width - titleX - padding, 1);
    
    
    NSMutableAttributedString *attributedString1 = [[NSMutableAttributedString alloc] initWithString:translate.translate attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    [attributedString1 addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [attributedString1 length])];
    CGSize translateSize = [attributedString1 boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
    _translateFrame = CGRectMake(titleX+ padding /2,CGRectGetMaxY(_spacelineFrame) + padding, size.width, translateSize.height);
    
    

    _rightViewFrame = CGRectMake(padding,titleY, Main_Screen_Width - padding*2, CGRectGetMaxY(_translateFrame));

    
    CGSize timeSize = [XUtil sizeWithString:translate.showtime font:[UIFont systemFontOfSize:12] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    _timeFrame = CGRectMake(titleX, CGRectGetMaxY(_rightViewFrame) + padding/2, timeSize.width + 4, timeSize.height);
    
    
    self.cellHeight = CGRectGetMaxY(_timeFrame) + 5;
    
    
}

@end
