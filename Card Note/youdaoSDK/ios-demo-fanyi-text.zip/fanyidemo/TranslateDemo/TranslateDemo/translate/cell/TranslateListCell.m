//
//  LiveRoomCell.m
//  HiBuy
//
//  Created by youagoua on 15/3/21.
//  Copyright (c) 2015年 xiaoyou. All rights reserved.
//
#import "TranslateListCell.h"
#import "NSString+URL.h"
#import "XUtil.h"
#import "UIView_extra.h"
#import "Translate.h"
#import "NSUserDefaultsUtil.h"
#import "DetailWordsViewController.h"
#import "HUDUtil.h"
#import "ACMacros.h"
@implementation TranslateListCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    // NSLog(@"cellForRowAtIndexPath");
    static NSString *identifier = @"Translate";
    // 1.缓存中取
    TranslateListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    // 2.创建
    if (cell == nil) {
        cell = [[TranslateListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    //if(self) 判断初始化是否成功，这里继承系统类的话基本可以忽略
    if (self) {
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        _appDelegate = appDelegate;
        self.contentView.backgroundColor = [XUtil hexToRGB:@"ecf0f1"];
        
        UIView *rightView = [[UIView alloc] init];
        [self.contentView addSubview:rightView];
        
        CALayer *ll = [rightView layer];   //获取ImageView的层
        [ll setMasksToBounds:YES];
        [ll setCornerRadius:5.0];
        _rightView = rightView;
        _rightView.backgroundColor = [UIColor whiteColor];
        
        UILabel *contentLabel = [[UILabel alloc] init];
        [contentLabel setTextColor: [XUtil hexToRGB:@"666666"]];
        contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
        contentLabel.numberOfLines = 0;
        [contentLabel setFont:[UIFont systemFontOfSize:16]];
        [self.contentView addSubview:contentLabel];
        _contentLabel = contentLabel;
     
        UILabel *spacingLineLabel = [[UILabel alloc] init];
        [spacingLineLabel setBackgroundColor: [XUtil hexToRGB:@"f3f3f3"]];
        [self.contentView addSubview:spacingLineLabel];
        _spacingLineLabel = spacingLineLabel;
        
        UILabel *translateLabel = [[UILabel alloc] init];
        translateLabel.lineBreakMode = NSLineBreakByWordWrapping;
        translateLabel.numberOfLines = 0;
        [translateLabel setTextColor: [XUtil hexToRGB:@"666666"]];

        [translateLabel setFont:[UIFont systemFontOfSize:16]];
        [self.contentView addSubview:translateLabel];
        _translateLabel = translateLabel;
        
        _translateLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playRemoteFile)];
        [_translateLabel addGestureRecognizer:tap];
        
        UILabel *timeLabel = [[UILabel alloc] init];
        [timeLabel setTextColor: [XUtil hexToRGB:@"666666"]];
        timeLabel.lineBreakMode = NSLineBreakByWordWrapping;
        timeLabel.numberOfLines = 1;
        [timeLabel setFont:[UIFont systemFontOfSize:12]];
        [self.contentView addSubview:timeLabel];
        
        timeLabel.textAlignment = TextAlignmentLeft;
        _timeLabel = timeLabel;
        
    }
    return self;
}

- (void)playRemoteFile
{

}


-(void) moreClick{
    Translate *translate = _translateFrame.translate;
    DetailWordsViewController *detailWordsViewController = [[DetailWordsViewController alloc]init];
    detailWordsViewController.translate = translate;
    AppDelegate * appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate.controller pushViewController:detailWordsViewController animated:YES];
    
//    //跳转到词典
//    NSURL *ditcApp = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"yddict://youdao.com/dict?q=%@", translate.content]];
//    if([[UIApplication sharedApplication] canOpenURL:ditcApp]){
//           [[UIApplication sharedApplication] openURL:ditcApp];
//    }else{
//        NSURL *ditcWebApp = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://dict.youdao.com/w/%@", [translate.content URLEncodedString]]];
//        [[UIApplication sharedApplication] openURL:ditcWebApp];
//    }
 
}

- (void)loadWithFrame:(TranslateFrame *)translateFrame
{
    _translateFrame = translateFrame;
    [self settingData];
    [self settingFrame];
}

/**
 *  设置子控件的数据
 */
- (void)settingData
{
    Translate *translate = _translateFrame.translate;
    
    CGSize size = CGSizeMake([[UIScreen mainScreen] bounds].size.width - Main_Screen_Width*120/640,0);
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:translate.content attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:8];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [attributedString length])];
    
    _contentLabel.attributedText = attributedString;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(moreClick)];
    _rightView.userInteractionEnabled = YES;
    [_rightView addGestureRecognizer:tap];
    
    NSMutableAttributedString *attributedString1 = [[NSMutableAttributedString alloc] initWithString:translate.translate attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    [attributedString1 addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [attributedString1 length])];
    _translateLabel.attributedText = attributedString1;
    
    _timeLabel.text = translate.showtime;
    
}
/**
 *  设置子控件的frame
 */
- (void)settingFrame
{
    _rightView.frame = _translateFrame.rightViewFrame;
    _contentLabel.frame = _translateFrame.contentFrame;
    _translateLabel.frame = _translateFrame.translateFrame;
    _spacingLineLabel.frame = _translateFrame.spacelineFrame;
    _timeLabel.frame = _translateFrame.timeFrame;

}


@end
