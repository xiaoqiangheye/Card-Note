//
//  LiveRoomCell.h
//  HiBuy
//
//  Created by youagoua on 15/3/21.
//  Copyright (c) 2015年 xiaoyou. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TranslateFrame.h"
#import "AppDelegate.h"
@class TranslateFrame;
@interface TranslateListCell : UITableViewCell



@property (nonatomic, weak) UIView *rightView;


@property (nonatomic, weak) UILabel *contentLabel;

@property (nonatomic, weak) UILabel *translateLabel;

@property (nonatomic, weak) UILabel *timeLabel;

@property (nonatomic, weak) UILabel *spacingLineLabel;

@property (nonatomic, strong) TranslateFrame *translateFrame;
@property (nonatomic, weak) AppDelegate *appDelegate;

- (void)loadWithFrame:(TranslateFrame *)translateFrame;

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
