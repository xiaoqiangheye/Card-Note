//
//  IndexCell.h
//  fanyidemo
//
//  Created by lilu on 2018/11/1.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface IndexCell : UITableViewCell
@property (nonatomic, weak) UILabel *indexLabel;
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
