//
//  IndexCell.m
//  fanyidemo
//
//  Created by lilu on 2018/11/1.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "IndexCell.h"

@implementation IndexCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *identifier = @"IndexCell";
    IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[IndexCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        UIView *redView = [[UIView alloc] initWithFrame:CGRectMake(20, 10, [UIScreen mainScreen].bounds.size.width - 40, 50)];
        redView.backgroundColor = [UIColor redColor];
        [self addSubview:redView];
        
        UILabel *indexLabel = [[UILabel alloc] initWithFrame:redView.frame];
        indexLabel.numberOfLines = 1;
        indexLabel.textColor = [UIColor whiteColor];
        indexLabel.font = [UIFont systemFontOfSize:18];
        indexLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:indexLabel];
        self.indexLabel = indexLabel;
    }
    return self;
}

@end
