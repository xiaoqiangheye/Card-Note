//
//  YDSpeechResult.m
//  speechtransonline
//
//  Created by lilu on 2017/12/18.
//  Copyright © 2017年 lilu. All rights reserved.
//

#import "YDSpeechResult.h"

@implementation YDSpeechResult

@end
