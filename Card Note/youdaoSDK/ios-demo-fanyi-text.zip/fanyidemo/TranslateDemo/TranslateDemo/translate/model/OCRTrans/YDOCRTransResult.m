//
//  YDOCRTransResult.m
//  fanyidemo
//
//  Created by lilu on 2018/4/23.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "YDOCRTransResult.h"

@implementation YDOCRTransResult
+ (NSDictionary *)mj_objectClassInArray {
    return @{@"resRegions" : @"YDOCRTransRegion"};
}
@end
