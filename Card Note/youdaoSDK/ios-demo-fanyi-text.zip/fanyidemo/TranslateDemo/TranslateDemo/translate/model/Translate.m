//
//  Translate.m
//
//  Created by 白静 on 8/17/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import "Translate.h"
#import "XUtil.h"
@implementation Translate
- (void)formData
{
    [self setCreatetime];
    
}

-(void)setCreatetime{
    NSDate *d = [NSDate dateWithTimeIntervalSince1970:[_createstime longLongValue]];
    NSDate *today = [NSDate date];
    NSDate *yes = [NSDate dateWithTimeIntervalSince1970:[_createstime longLongValue]  + 86400];

    if ([XUtil isSameDay:d otherDay:today]) {
        long interval = today.timeIntervalSince1970  - d.timeIntervalSince1970;
        int t = interval / 3600;
        if (t > 0) {
            _showtime = [NSString stringWithFormat:@"%ld小时前",t];
        } else {
            _showtime = @"刚刚";
        }
    }else if ([XUtil isSameDay:yes otherDay:today]) {
        _showtime = @"昨天";
    }else{
        //2016.06.23这种格式
        _showtime = [XUtil dateToString:d];
    }
}

@end
