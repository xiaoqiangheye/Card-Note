//
//  YDSpeechResult.h
//  speechtransonline
//
//  Created by lilu on 2017/12/18.
//  Copyright © 2017年 lilu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDSpeechResult : NSObject
/* 翻译结果发音地址，翻译成功一定存在 */
@property (nonatomic, copy) NSString *tSpeakUrl;
/* 翻译结果错误码，一定存在 */
@property (nonatomic, copy) NSString *errorCode;
/* 源语言文本，翻译成功一定存在 */
@property (nonatomic, copy) NSString *query;
/* 翻译结果，翻译成功一定存在 */
@property (nonatomic, strong) NSArray *translation;
/* 词典deeplink */
@property (nonatomic, strong) NSDictionary *dict;
/* 词典web deeplink */
@property (nonatomic, strong) NSDictionary *webdict;
/* 源语言发音地址，翻译成功一定存在 */
@property (nonatomic, copy) NSString *speakUrl;
@end

