//
//  YDOCRTransRegion.h
//  fanyidemo
//  图片翻译结果解析子元素
//  Created by lilu on 2018/4/23.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOCRTransRegion : NSObject
/* 区域范围，四个值：左上角的x值，左上角的y值，区域的的宽，区域的高，例如：134,0,1066,249 */
@property (nonatomic, copy) NSString *boundingBox;
/* 该区域的原文 */
@property (nonatomic, copy) NSString *context;
/* 行高 */
@property (nonatomic, copy) NSString *lineheight;
/* 行数（用于前端排版） */
@property (nonatomic, copy) NSString *linesCount;
/* 翻译结果 */
@property (nonatomic, copy) NSString *tranContent;
/* 行间距 */
@property (nonatomic, copy) NSString *linespace;
@end
/*
 {
 boundingBox = "2,7,676,205";
 context = " Before I was five years old, my parents gave me what I wanted, but as I became bigger, they changed their attitude towards me. My parents no longer satisfy me with all I want. When I want to buy a new dress, my mother won' t buy for me directly, she asks me to do something to exchange for it. Such as doing the housework or making progress in the study. What' s more, when I meet the difficulties, my parents won' t solve them for me immediately, instead, they will leave me to think about them and help me to solve them. What my parents do to";
 lineheight = 20;
 linesCount = 7;
 linespace = 10;
 tranContent = "\U5728\U6211\U4e94\U5c81\U4e4b\U524d\Uff0c\U6211\U7684\U7236\U6bcd\U7ed9\U4e86\U6211\U60f3\U8981\U7684\U4e1c\U897f\Uff0c\U4f46\U662f\U5f53\U6211\U53d8\U5f97\U66f4\U5927\U7684\U65f6\U5019\Uff0c\U4ed6\U4eec\U6539\U53d8\U4e86\U5bf9\U6211\U7684\U6001\U5ea6\U3002\U6211\U7684\U7236\U6bcd\U4e0d\U518d\U6ee1\U8db3\U4e8e\U6211\U6240\U9700\U8981\U7684\U4e00\U5207\U3002\U5f53\U6211\U60f3\U4e70\U4e00\U4ef6\U65b0\U8863\U670d\U65f6\Uff0c\U5988\U5988\U4e0d\U4f1a\U76f4\U63a5\U7ed9\U6211\U4e70\Uff0c\U5979\U8981\U6211\U505a\U70b9\U4ec0\U4e48\U6765\U4ea4\U6362\U3002\U6bd4\U5982\U505a\U5bb6\U52a1\U6216\U8005\U5728\U5b66\U4e60\U4e0a\U53d6\U5f97\U8fdb\U6b65\U3002\U66f4\U91cd\U8981\U7684\U662f\Uff0c\U5f53\U6211\U9047\U5230\U56f0\U96be\U7684\U65f6\U5019\Uff0c\U6211\U7684\U7236\U6bcd\U4e0d\U4f1a\U9a6c\U4e0a\U5e2e\U6211\U89e3\U51b3\Uff0c\U800c\U662f\U8ba9\U6211\U53bb\U601d\U8003\Uff0c\U5e2e\U52a9\U6211\U89e3\U51b3\U95ee\U9898\U3002\U6211\U7236\U6bcd\U505a\U4ec0\U4e48!";
 }
 */
