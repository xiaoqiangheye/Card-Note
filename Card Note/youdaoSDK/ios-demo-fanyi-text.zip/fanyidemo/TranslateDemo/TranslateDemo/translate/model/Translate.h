//
//  Translate.h
//
//  Created by 白静 on 8/17/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TranslateSDK.h"
@interface Translate : NSObject

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *translate;

@property (nonatomic, copy) NSString * showtime;//展示的时间
@property (nonatomic, copy) NSString * createstime;//实际翻译时间
@property (nonatomic, strong) YDTranslate * ydTranslate;

- (void)formData;
@end
