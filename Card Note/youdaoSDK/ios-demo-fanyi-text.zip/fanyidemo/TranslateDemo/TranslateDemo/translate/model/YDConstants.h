//
//  YDConstants.h
//  fanyidemo
//
//  Created by lilu on 2018/11/7.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const yd_kIndexTestAppkey;
extern NSString *const yd_kIndexOnlineAppkey;
extern NSString *const yd_kStreamASRAppkey;
extern NSString *const yd_kSpeechEvaluationAppkey;

extern NSString *const yd_kSentenceOfflineCePath;
extern NSString *const yd_kHanyucidianHhPath;
extern NSString *const yd_kOfflineTranslateBaPath;
extern NSString *const yd_kOfflineTranslateBbPath;

extern NSString *const yd_SpeechEvaluationWord;
extern NSString *const yd_SpeechEvaluationSentence;
