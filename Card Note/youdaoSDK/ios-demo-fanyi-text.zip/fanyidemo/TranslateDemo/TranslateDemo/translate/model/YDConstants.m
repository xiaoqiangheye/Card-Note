//
//  YDConstants.m
//  fanyidemo
//
//  Created by lilu on 2018/11/7.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "YDConstants.h"

NSString *const yd_kIndexTestAppkey = @"your appkey";
NSString *const yd_kIndexOnlineAppkey = @"your appkey";
NSString *const yd_kStreamASRAppkey = @"your appkey";
NSString *const yd_kSpeechEvaluationAppkey = @"your appkey";

NSString *const yd_kSentenceOfflineCePath = @"https://download.ydstatic.com/dictmobile/dictlib/4.0/iphone/ce.zip";
NSString *const yd_kHanyucidianHhPath = @"http://ydschool-online.nos.netease.com/1495768152485hh.zip";
NSString *const yd_kOfflineTranslateBaPath = @"http://nb269x.corp.youdao.com:18080/sdkdev/ba160111.ydd";
NSString *const yd_kOfflineTranslateBbPath = @"http://nb269x.corp.youdao.com:18080/sdkdev/bb160111.ydd";

NSString *const yd_SpeechEvaluationWord = @"transportation";
NSString *const yd_SpeechEvaluationSentence = @"Imagine what you can do with the money you save!";
