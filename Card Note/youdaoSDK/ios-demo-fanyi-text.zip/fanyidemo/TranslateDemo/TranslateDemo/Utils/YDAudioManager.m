//
//  YDAudioManager.m
//  fanyidemo
//
//  Created by lilu on 2018/11/8.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "YDAudioManager.h"
#import <AVFoundation/AVFoundation.h>

@interface YDAudioManager ()
@property (nonatomic, strong) AVAudioRecorder *recorder; //录音器
@property (nonatomic, strong) AVAudioPlayer *player; //播放器
@property (nonatomic, strong) NSURL *recordFileUrl; //录音文件地址
@end


@implementation YDAudioManager
#pragma mark - init
+ (instancetype)manager {
    YDAudioManager *manager = [[self alloc] init];
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        self.rate = 16000;
        self.maxRecordTime = 15;
        self.fileName = @"record.wav";
    }
    return self;
}

- (void)setFileName:(NSString *)fileName {
    _fileName = fileName;
    //1.获取沙盒地址
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:self.fileName];
    //2.获取文件路径
    _recordFileUrl = [NSURL fileURLWithPath:path];
}

#pragma mark - public func
- (void)startRecord {
    NSLog(@"开始录音");
    
    AVAudioSession *session =[AVAudioSession sharedInstance];
    NSError *sessionError;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    
    if (session == nil) {
        NSLog(@"Error creating session: %@",[sessionError description]);
    }else{
        [session setActive:YES error:nil];
    }
    
    //设置参数
    NSDictionary *recordSetting = [[NSDictionary alloc] initWithObjectsAndKeys:
                                   //采样率  8000/11025/22050/44100/96000（影响音频的质量）
                                   [NSNumber numberWithInteger:self.rate],AVSampleRateKey,
                                   // 音频格式
                                   [NSNumber numberWithInt: kAudioFormatLinearPCM],AVFormatIDKey,
                                   //采样位数  8、16、24、32 默认为16
                                   [NSNumber numberWithInt:16],AVLinearPCMBitDepthKey,
                                   // 音频通道数 1 或 2
                                   [NSNumber numberWithInt: 1], AVNumberOfChannelsKey,
                                   //录音质量
                                   [NSNumber numberWithInt:AVAudioQualityHigh],AVEncoderAudioQualityKey,
                                   nil];
    
    _recorder = [[AVAudioRecorder alloc] initWithURL:self.recordFileUrl settings:recordSetting error:nil];
    if (_recorder) {
        _recorder.meteringEnabled = YES;
        [_recorder prepareToRecord];
        [_recorder record];
        //最长支持15s的语音翻译
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.maxRecordTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self stopRecord];
        });
    }else{
        NSLog(@"音频格式和文件存储格式不匹配,无法初始化Recorder");
    }
}

- (void)stopRecord {
    if ([self.recorder isRecording]) {
        NSLog(@"停止录音");
        [self.recorder stop];
    }
}

- (void)playRecord {
    [self playAudio:[self audioData]];
}

- (void)playAudio:(NSData *)data {
    self.player = [[AVAudioPlayer alloc] initWithData:data error:nil];
    [self.player play];
}

- (void)stopPlay {
    if (self.player && [self.player isPlaying]) {
        [self.player stop];
    }
}

- (NSData *)audioData {
    return [NSData dataWithContentsOfURL:self.recordFileUrl];
}
@end
