//
//  YDAudioManager.h
//  fanyidemo
//  录音 & 播放 工具
//  Created by lilu on 2018/11/8.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface YDAudioManager : NSObject
/**
 最长录音市场，默认15s
 */
@property (nonatomic, assign) NSInteger maxRecordTime;
/**
 采样率
 */
@property (nonatomic, assign) NSInteger rate;

/**
 音频保存文件名
 */
@property (nonatomic, copy) NSString *fileName;

/**
 返回一个manager

 @return manager
 */
+ (instancetype)manager;
/**
 开始录音
 */
- (void)startRecord;
/**
 停止录音
 */
- (void)stopRecord;
/**
 播放录音
 */
- (void)playRecord;
/**
 播放录音
 */
- (void)playAudio:(NSData *)data;
/**
 停止播放
 */
- (void)stopPlay;
/**
 获取录音数据

 @return 录音data
 */
- (NSData *)audioData;
@end

