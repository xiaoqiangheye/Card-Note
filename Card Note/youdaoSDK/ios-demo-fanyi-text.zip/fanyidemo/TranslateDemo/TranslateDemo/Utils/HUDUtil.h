//
//  HUDUtil.h
//  sdata
//
//  Created by 白静 on 5/21/16.
//  Copyright © 2016 Netease Youdao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface HUDUtil : NSObject
+(void)show:(UIView *)view text:(NSString *)text;
@end
