//
//  StreamASRController.m
//  fanyidemo
//
//  Created by lilu on 2018/11/1.
//  Copyright © 2018年 网易有道. All rights reserved.
//

#import "StreamASRController.h"
#import "StreamASRSDK.h"
#import "ACMacros.h"

@interface StreamASRController ()<YDSpeechRecognizerDelegate>
@property (nonatomic, strong) YDSpeechRecognizer *recognizer;
@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, copy) NSString *lastSentenceText;
@property (nonatomic, strong) NSMutableString *displayingText;
@property (nonatomic, assign) NSUInteger currentSentenceIndex;
@property (nonatomic, strong) UITextView *recognizedLabel;
@property (nonatomic, strong) NSTimer *animationTimer;
@property (nonatomic, assign) NSUInteger pointNum;
@property (nonatomic, strong) UIButton *englishBtn;//英文按钮
@property (nonatomic, strong) UIButton *chineseBtn;//中文按钮
@property (nonatomic, strong) UIButton *ceMixBtn;//中英文按钮
@property (nonatomic, strong)UIButton * lastBtn;//上一次选中的按钮
@property (nonatomic, strong)UIButton * clickBtn;//选中的按钮
@property (nonatomic, copy) NSString *language;
@end

@implementation StreamASRController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpViews];
    
    //NSString *const appKey = @"5af39f94-1d05-44c5-9311-fd2cba648c79";

     NSString *const appKey = @"your appKey";
    
    [YDTranslateInstance sharedInstance].appKey = appKey;//yd_kStreamASRAppkey;
    [YDTranslateInstance sharedInstance].isTestMode = NO;
    
    
    self.recognizer = [YDSpeechRecognizer sharedRecognizer];
    self.language = @"zh-CHS";
    YDSpeechRecognizerParam *param = [YDSpeechRecognizerParam param];
    param.langType = self.language;
    self.recognizer.param = param;
    self.recognizer.delegate = self;
}

- (void)setUpViews {
    
    
    NSComparisonResult order = [[UIDevice currentDevice].systemVersion compare: @"7.0" options: NSNumericSearch];
    if (order == NSOrderedSame || order == NSOrderedDescending)
    {
        // OS version >= 7.0
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"有道ASR";
    NSTimer *animationTimer = [NSTimer timerWithTimeInterval:0.7 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:animationTimer forMode:NSRunLoopCommonModes];
    [animationTimer setFireDate:[NSDate distantFuture]];
    self.animationTimer = animationTimer;
    
    NSArray * array = [[NSArray alloc]initWithObjects:@"英文",@"中文",@"中英", nil];
    NSUInteger btnNumber =  array.count;
    for (int i = 0; i < btnNumber; i++) {
        UIButton * Btn = [UIButton new];
        Btn.layer.cornerRadius = 4.0;
        Btn.layer.masksToBounds = YES;
        Btn.titleLabel.font = [UIFont systemFontOfSize:18];
        [Btn setTitle:array[i] forState:UIControlStateNormal];
        [Btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        [Btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        Btn.frame = CGRectMake(Main_Screen_Width/4*(i+1)-30, 20, 50, 30);
        [self.view addSubview:Btn];
        Btn.tag = i;
        switch (i) {
                //英文按钮
            case 0:{
                [Btn addTarget:self action:@selector(selectEnglish) forControlEvents:UIControlEventTouchUpInside];
                self.englishBtn = Btn;
                break;
            }
                //中文按钮
            case 1:{
                [Btn addTarget:self action:@selector(selectChinese) forControlEvents:UIControlEventTouchUpInside];
                self.chineseBtn = Btn;
                break;
            }
                //混合按钮
            case 2:{
                [Btn addTarget:self action:@selector(selectCEMix) forControlEvents:UIControlEventTouchUpInside];
                self.ceMixBtn = Btn;
                break;
            }
        }
    }
    
//    UIButton *englishBtn = [UIButton new];
//    englishBtn.layer.cornerRadius = 4.0;
//    englishBtn.layer.masksToBounds = YES;
//    englishBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    [englishBtn setTitle:@"英文" forState:UIControlStateNormal];
//    [englishBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
//    [englishBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//    englishBtn.frame = CGRectMake(Main_Screen_Width * 0.5 - 60, 20, 50, 30);
//    [self.view addSubview:englishBtn];
//    [englishBtn addTarget:self action:@selector(selectEnglish) forControlEvents:UIControlEventTouchUpInside];
//    self.englishBtn = englishBtn;
//
//    UIButton *chineseBtn = [UIButton new];
//    chineseBtn.layer.cornerRadius = 4.0;
//    chineseBtn.layer.masksToBounds = YES;
//    chineseBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    [chineseBtn setTitle:@"中文" forState:UIControlStateNormal];
//    [chineseBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
//    [chineseBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//    chineseBtn.frame = CGRectMake(Main_Screen_Width * 0.5 + 10, 20, 50, 30);
//    [self.view addSubview:chineseBtn];
//    [chineseBtn addTarget:self action:@selector(selectChinese) forControlEvents:UIControlEventTouchUpInside];
//    self.chineseBtn = chineseBtn;
    
    UITextView *recognizedText = [UITextView new];
    recognizedText.backgroundColor = [UIColor lightGrayColor];
    recognizedText.layer.cornerRadius = 5.0;
    recognizedText.layer.masksToBounds = YES;
    recognizedText.layer.borderColor = [UIColor blackColor].CGColor;
    recognizedText.frame = CGRectMake(30, MaxY(self.chineseBtn) + 10, Main_Screen_Width - 60, Main_Screen_Height - 234);
    recognizedText.font = [UIFont systemFontOfSize:14];
    recognizedText.textColor = [UIColor blackColor];
    recognizedText.editable = NO;
    [self.view addSubview:recognizedText];
    self.recognizedLabel = recognizedText;
    
    CGFloat width = (Main_Screen_Width - 140) / 3;
    UIButton *start = [UIButton new];
    [start setTitle:@"开始" forState:UIControlStateNormal];
    [start setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    start.titleLabel.font = [UIFont systemFontOfSize:20];
    [start setBackgroundColor:BTNBG_BLUE];
    start.frame = CGRectMake(Main_Screen_Width * 0.5 - width - 10, MaxY(self.recognizedLabel) + 10, width, 40);
    start.layer.cornerRadius = 5.0;
    start.layer.masksToBounds = YES;
    [self.view addSubview:start];
    [start addTarget:self action:@selector(startRecognize) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *stop = [UIButton new];
    [stop setTitle:@"停止" forState:UIControlStateNormal];
    [stop setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    stop.titleLabel.font = [UIFont systemFontOfSize:20];
    [stop setBackgroundColor:BTNBG_BLUE];
    stop.frame = CGRectMake(Main_Screen_Width * 0.5 + 10, Y(start), width, 40);
    stop.layer.cornerRadius = 5.0;
    stop.layer.masksToBounds = YES;
    [self.view addSubview:stop];
    [stop addTarget:self action:@selector(stopRecognize) forControlEvents:UIControlEventTouchUpInside];
    
    //    UIButton *cancel = [UIButton new];
    //    [cancel setTitle:@"取消" forState:UIControlStateNormal];
    //    [cancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //    cancel.titleLabel.font = [UIFont systemFontOfSize:20];
    //    [cancel setBackgroundColor:BTNBG_BLUE];
    //    cancel.frame = CGRectMake(90 + 2 * width, Main_Screen_Height - 90, width, 40);
    //    cancel.layer.cornerRadius = 5.0;
    //    cancel.layer.masksToBounds = YES;
    //    [self.view addSubview:cancel];
    //    [cancel addTarget:self action:@selector(cancelRecognize) forControlEvents:UIControlEventTouchUpInside];
    _clickBtn = _chineseBtn;
    
}

- (void)tick:(NSTimer *)timer {
    if (self.pointNum == 0) {
        self.title = @"讲话中";
        self.pointNum++;
    } else {
        NSMutableString *pointStr = [NSMutableString stringWithCapacity:3];
        for (int i = 0; i < self.pointNum; i++) {
            [pointStr appendString:@"."];
        }
        self.title = [NSString stringWithFormat:@"讲话中%@", pointStr];
        self.pointNum++;
        if (self.pointNum > 3) {
            self.pointNum = 0;
        }
    }
}

- (void)selectEnglish {
    if (self.recognizer.isListening) {
        [self showHint:@"识别中无法切换"];
    } else {
        _clickBtn = _englishBtn;
        self.language = @"en";
    }
}

- (void)selectChinese {
    if (self.recognizer.isListening) {
        [self showHint:@"识别中无法切换"];
    } else {
        _clickBtn = _chineseBtn;
        self.language = @"zh-CHS";
    }
}

- (void)selectCEMix{
    if (self.recognizer.isListening) {
        [self showHint:@"识别中无法切换"];
    } else{
        _clickBtn = _ceMixBtn;
        self.language = @"enzh";
        
    }
}

- (void)setLanguage:(NSString *)language {
    _language = language;
    if(_clickBtn.tag == _lastBtn.tag){
        return;
    }
    _clickBtn.backgroundColor = BTNBG_BLUE;
    _clickBtn.selected = YES;
    _lastBtn.selected = NO;
    _lastBtn.backgroundColor = [UIColor clearColor];
    _lastBtn = _clickBtn;
//    _language = language;
//    if ([self.language isEqualToString:@"zh-CHS"]) {
//        self.chineseBtn.backgroundColor = BTNBG_BLUE;
//        self.chineseBtn.selected = YES;
//        self.englishBtn.selected = NO;
//        self.englishBtn.backgroundColor = [UIColor clearColor];
//    } else if ([self.language isEqualToString:@"en"]){
//        self.englishBtn.backgroundColor = BTNBG_BLUE;
//        self.englishBtn.selected = YES;
//        self.chineseBtn.selected = NO;
//        self.chineseBtn.backgroundColor = [UIColor clearColor];
//    }
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
}

- (void)startSpeakingAnimation {
    [self showHint:@"开始录音"];
    self.pointNum = 0;
    [self.animationTimer setFireDate:[NSDate distantPast]];
}

- (void)endSpekingAnimation {
    [self showHint:@"结束录音"];
    [self.animationTimer setFireDate:[NSDate distantFuture]];
    dispatch_async(dispatch_get_main_queue(), ^{
        self.title = @"有道ASR";
    });
}

- (void)resetDisplayView {
    self.dataArr = [NSMutableArray array];
    self.currentSentenceIndex = 0;
    self.displayingText = [[NSMutableString alloc] initWithCapacity:100000];
    self.lastSentenceText = nil;
    self.recognizedLabel.text = @"";
}

- (void)startRecognize {
    if (!self.recognizer.isListening) {
        [self resetDisplayView];
    }
    self.recognizer.param.langType = self.language;
    [self.recognizer startListening];
}

- (void)stopRecognize {
    [self.recognizer stopListening];
}

- (void)cancelRecognize {
    
}

- (void)showHint:(NSString *)hintText {
    dispatch_async(dispatch_get_main_queue(), ^{
        UILabel *hintLabel = [UILabel new];
        hintLabel.layer.cornerRadius = 5.0;
        hintLabel.layer.masksToBounds = YES;
        hintLabel.alpha = 0.0f;
        hintLabel.backgroundColor = [UIColor blackColor];
        hintLabel.textAlignment = NSTextAlignmentCenter;
        hintLabel.textColor = [UIColor whiteColor];
        hintLabel.font = [UIFont systemFontOfSize:16.0];
        hintLabel.text = hintText;
        hintLabel.frame = CGRectMake(120, Main_Screen_Height / 2 - 15, Main_Screen_Width - 240, 30);
        [self.view addSubview:hintLabel];
        [self.view setNeedsDisplay];
        [UIView animateWithDuration:0.3 animations:^{
            hintLabel.alpha = 0.8f;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:1.0 delay:1.0 options:UIViewAnimationOptionShowHideTransitionViews animations:^{
                hintLabel.alpha = 0.02;
            } completion:^(BOOL finished) {
                hintLabel.alpha = 0;
                [hintLabel removeFromSuperview];
            }];
        }];
    });
}

#pragma mark - speech recognizer delegate
- (void)onBeginOfSpeech {
    [self startSpeakingAnimation];
    NSLog(@"------speech start-----");
}

- (void)onEndOfSpeech {
    [self endSpekingAnimation];
    NSLog(@"------speech end-----");
}

- (void)onResults:(NSDictionary *)result isLast:(BOOL)isLast {
    NSString *sentence = result[@"sentence"];
    self.recognizedLabel.text = [NSString stringWithFormat:@"%@%@", self.displayingText, sentence];
    if (isLast) {
        [self.displayingText appendString:sentence];
    }
    //    NSDictionary *originDic = (NSDictionary *)result;
    //    NSString *action = originDic[@"action"];
    //    NSString *errorCode = originDic[@"errorCode"];
    //    if ([action isEqualToString:@"recognition"] && [errorCode isEqualToString:@"0"]) {
    //        NSArray *tempArr = originDic[@"result"];
    //        NSDictionary *resultDic = [tempArr firstObject];
    //
    //        NSUInteger seg_id = [resultDic[@"seg_id"] integerValue];
    //        NSDictionary *stDic = resultDic[@"st"];;
    //
    //        NSArray<NSDictionary *> *wsArr = stDic[@"ws"];
    //        NSMutableString *sentence = [NSMutableString string];
    //        [wsArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    //            NSString *w = obj[@"w"];
    //            [sentence appendString:w];
    //        }];
    //        [self.dataArr addObject:[NSString stringWithFormat:@"第%lu句:%@,type:%lu", seg_id, sentence, [stDic[@"type"] integerValue]]];
    //        if (self.language == DL_CHINESE) {
    //            self.lastSentenceText = sentence;
    //            NSString *currentDisplayingText = [self.displayingText copy];
    //            dispatch_async(dispatch_get_main_queue(), ^{
    //                self.recognizedLabel.text = [NSString stringWithFormat:@"%@%@", currentDisplayingText, sentence];
    //            });
    //            NSUInteger type = [stDic[@"type"] integerValue];
    //            if (type == 0) {
    //                [self.displayingText appendString:self.lastSentenceText];
    //            }
    //        } else {
    //            if (![sentence isEqualToString:@""] && ![sentence isEqualToString:self.lastSentenceText]) {
    //                if (seg_id > self.currentSentenceIndex) {
    //                    [self.displayingText appendString:self.lastSentenceText];
    //                    self.currentSentenceIndex++;
    //                }
    //                self.lastSentenceText = sentence;
    //                dispatch_async(dispatch_get_main_queue(), ^{
    //                    self.recognizedLabel.text = [NSString stringWithFormat:@"%@%@", self.displayingText, sentence];
    //                });
    //            }
    //        }
    //    }
}

- (void)onCompleted:(NSError *)speechError {
    [self endSpekingAnimation];
    NSLog(@"------speech completed-----");
}

- (void)onConstantlyQuietIsBOS:(BOOL)isBOS {
    NSLog(@"检测到%@静音", isBOS ? @"前端点" : @"后端点");
}

@end
